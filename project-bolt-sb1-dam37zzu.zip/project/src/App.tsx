import React, { useState, useEffect } from 'react';
import { 
  ShoppingCart, 
  Package2, 
  Grid3X3, 
  Users, 
  CheckCircle, 
  Gamepad2, 
  Phone, 
  Info, 
  Download,
  Moon,
  Sun,
  Shield,
  StickyNote,
  Calculator,
  Calendar,
  Clock,
  Camera,
  Sparkles,
  Book,
  Brain,
  Star,
  Menu,
  X,
  Armchair,
  Wrench,
  Zap,
  Package,
  Smartphone,
  Play,
  Crown,
  MessageCircle,
  Settings,
  Home,
  Search,
  Heart,
  User,
  Bell,
  Volume2,
  VolumeX,
  Wifi,
  WifiOff,
  Globe,
  Languages,
  Palette,
  Monitor,
  Smartphone as SmartphoneIcon,
  Tablet,
  RefreshCw,
  Database,
  HardDrive,
  Activity
} from 'lucide-react';
import Navigation from './components/Navigation';
import ShoppingSection from './components/ShoppingSection';
import GamesSection from './components/GamesSection';
import ToolsSection from './components/ToolsSection';
import QuranSection from './components/QuranSection';
import AILibrary from './components/AILibrary';
import ContactSection from './components/ContactSection';
import AboutSection from './components/AboutSection';
import StoreLinks from './components/StoreLinks';
import SpecialOrders from './components/SpecialOrders';
import DateTimeDisplay from './components/DateTimeDisplay';
import Cart from './components/Cart';

type Section = 'home' | 'categories' | 'products' | 'cart' | 'perfect-order' | 'companions' | 
              'other-services' | 'games' | 'contact' | 'about' | 'store-links' | 'tools' | 
              'quran' | 'ai-library' | 'special-orders' | 'settings';

function App() {
  const [currentSection, setCurrentSection] = useState<Section>('home');
  const [darkMode, setDarkMode] = useState(false);
  const [cartItems, setCartItems] = useState<any[]>([]);
  const [menuOpen, setMenuOpen] = useState(false);
  
  // إعدادات التطبيق الرئيسية
  const [appSettings, setAppSettings] = useState({
    notifications: true,
    sound: true,
    language: 'ar',
    theme: 'auto', // auto, light, dark
    fontSize: 'medium', // small, medium, large
    autoSync: true,
    offlineMode: false,
    dataUsage: 'normal', // low, normal, high
    location: true,
    analytics: true
  });
  
  // عدادات الأقسام
  const [sectionCounters, setSectionCounters] = useState({
    cart: 0,
    notifications: 0,
    messages: 0,
    favorites: 0,
    downloads: 0,
    orders: 0,
    games: 0,
    tools: 0,
    quran: 0,
    ai: 0
  });
  
  // حالة الاتصال والنظام
  const [systemStatus, setSystemStatus] = useState({
    online: navigator.onLine,
    battery: 100,
    storage: 85,
    memory: 60,
    lastSync: new Date()
  });

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);
  
  // تحديث حالة الاتصال
  useEffect(() => {
    const handleOnline = () => setSystemStatus(prev => ({ ...prev, online: true }));
    const handleOffline = () => setSystemStatus(prev => ({ ...prev, online: false }));
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);
  
  // تحديث عدادات الأقسام
  useEffect(() => {
    setSectionCounters(prev => ({
      ...prev,
      cart: cartItems.length,
      notifications: Math.floor(Math.random() * 5) + 1,
      messages: Math.floor(Math.random() * 3) + 1,
      favorites: Math.floor(Math.random() * 10) + 5,
      downloads: Math.floor(Math.random() * 20) + 10,
      orders: Math.floor(Math.random() * 8) + 2,
      games: 4,
      tools: 7,
      quran: 100,
      ai: 50
    }));
  }, [cartItems]);

  const mainSections = [
    { id: 'categories', title: 'المجموعات', icon: Grid3X3, description: 'تصفح المجموعات المختلفة' },
    { id: 'products', title: 'عرض المنتجات', icon: Package2, description: 'جميع المنتجات المتاحة' },
    { id: 'cart', title: 'سلة المشتريات', icon: ShoppingCart, description: 'مراجعة مشترياتك' },
    { id: 'perfect-order', title: 'مثالية الطلب', icon: CheckCircle, description: 'ضمان جودة طلبك' },
    { id: 'companions', title: 'المرافقين', icon: Users, description: 'خدمة المرافق الشخصي' },
    { id: 'other-services', title: 'خدمات أخرى', icon: Settings, description: 'خدمات إضافية متنوعة' },
    { id: 'games', title: 'الألعاب', icon: Gamepad2, description: 'ألعاب ترفيهية متنوعة' },
    { id: 'tools', title: 'الأدوات الذكية', icon: Wrench, description: 'مجموعة أدوات احترافية' },
    { id: 'quran', title: 'القرآن الكريم', icon: Book, description: 'تلاوة وقراءة' },
    { id: 'ai-library', title: 'مكتبة الذكاء الاصطناعي', icon: Brain, description: 'أدوات ذكية متقدمة' },
    { id: 'special-orders', title: 'الطلبات الخاصة', icon: Crown, description: 'طلبات مخصصة ومميزة' },
  ];

  const infoSections = [
    { id: 'contact', title: 'تواصل معنا', icon: Phone, description: 'خدمة العملاء والدعم' },
    { id: 'about', title: 'من نحن', icon: Info, description: 'معلومات عن التطبيق' },
    { id: 'store-links', title: 'روابط المتاجر', icon: Download, description: 'تحميل التطبيق' },
    { id: 'settings', title: 'الإعدادات', icon: Settings, description: 'إعدادات التطبيق' },
  ];

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    setAppSettings(prev => ({ ...prev, theme: !darkMode ? 'dark' : 'light' }));
  };

  const addToCart = (item: any) => {
    setCartItems(prev => [...prev, { ...item, id: Date.now() }]);
  };

  const removeFromCart = (id: number) => {
    setCartItems(prev => prev.filter(item => item.id !== id));
  };
  
  // مكون الإعدادات
  const SettingsSection = () => (
    <div className="space-y-8">
      <div className="text-center">
        <div className="flex justify-center mb-6">
          <div className="bg-gradient-to-br from-gray-600 to-gray-800 p-6 rounded-2xl shadow-2xl">
            <Settings className="w-16 h-16 text-white" />
          </div>
        </div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
          إعدادات التطبيق
        </h1>
        <p className="text-gray-600 dark:text-gray-400">
          تخصيص التطبيق حسب تفضيلاتك
        </p>
      </div>

      {/* حالة النظام */}
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl border border-gray-200 dark:border-gray-700 p-6">
        <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6 flex items-center space-x-2 space-x-reverse">
          <Activity className="w-6 h-6 text-blue-600" />
          <span>حالة النظام</span>
        </h2>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center p-4 bg-gray-50 dark:bg-gray-700 rounded-xl">
            <div className={`w-4 h-4 rounded-full mx-auto mb-2 ${systemStatus.online ? 'bg-green-500' : 'bg-red-500'}`}></div>
            <p className="text-sm font-medium text-gray-900 dark:text-white">
              {systemStatus.online ? 'متصل' : 'غير متصل'}
            </p>
          </div>
          <div className="text-center p-4 bg-gray-50 dark:bg-gray-700 rounded-xl">
            <div className="text-lg font-bold text-green-600 mb-1">{systemStatus.battery}%</div>
            <p className="text-sm text-gray-600 dark:text-gray-400">البطارية</p>
          </div>
          <div className="text-center p-4 bg-gray-50 dark:bg-gray-700 rounded-xl">
            <div className="text-lg font-bold text-blue-600 mb-1">{systemStatus.storage}%</div>
            <p className="text-sm text-gray-600 dark:text-gray-400">التخزين</p>
          </div>
          <div className="text-center p-4 bg-gray-50 dark:bg-gray-700 rounded-xl">
            <div className="text-lg font-bold text-purple-600 mb-1">{systemStatus.memory}%</div>
            <p className="text-sm text-gray-600 dark:text-gray-400">الذاكرة</p>
          </div>
        </div>
      </div>

      {/* الإعدادات العامة */}
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl border border-gray-200 dark:border-gray-700 p-6">
        <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">الإعدادات العامة</h2>
        
        <div className="space-y-6">
          {/* الإشعارات */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3 space-x-reverse">
              <Bell className="w-5 h-5 text-blue-600" />
              <span className="text-gray-900 dark:text-white">الإشعارات</span>
            </div>
            <button
              onClick={() => setAppSettings(prev => ({ ...prev, notifications: !prev.notifications }))}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                appSettings.notifications ? 'bg-blue-600' : 'bg-gray-300 dark:bg-gray-600'
              }`}
            >
              <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                appSettings.notifications ? 'translate-x-6' : 'translate-x-1'
              }`} />
            </button>
          </div>

          {/* الصوت */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3 space-x-reverse">
              {appSettings.sound ? <Volume2 className="w-5 h-5 text-green-600" /> : <VolumeX className="w-5 h-5 text-red-600" />}
              <span className="text-gray-900 dark:text-white">الصوت</span>
            </div>
            <button
              onClick={() => setAppSettings(prev => ({ ...prev, sound: !prev.sound }))}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                appSettings.sound ? 'bg-green-600' : 'bg-gray-300 dark:bg-gray-600'
              }`}
            >
              <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                appSettings.sound ? 'translate-x-6' : 'translate-x-1'
              }`} />
            </button>
          </div>

          {/* اللغة */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3 space-x-reverse">
              <Languages className="w-5 h-5 text-purple-600" />
              <span className="text-gray-900 dark:text-white">اللغة</span>
            </div>
            <select
              value={appSettings.language}
              onChange={(e) => setAppSettings(prev => ({ ...prev, language: e.target.value }))}
              className="px-3 py-1 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            >
              <option value="ar">العربية</option>
              <option value="en">English</option>
              <option value="fr">Français</option>
            </select>
          </div>

          {/* حجم الخط */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3 space-x-reverse">
              <Palette className="w-5 h-5 text-orange-600" />
              <span className="text-gray-900 dark:text-white">حجم الخط</span>
            </div>
            <select
              value={appSettings.fontSize}
              onChange={(e) => setAppSettings(prev => ({ ...prev, fontSize: e.target.value }))}
              className="px-3 py-1 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            >
              <option value="small">صغير</option>
              <option value="medium">متوسط</option>
              <option value="large">كبير</option>
            </select>
          </div>

          {/* المزامنة التلقائية */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3 space-x-reverse">
              <RefreshCw className="w-5 h-5 text-indigo-600" />
              <span className="text-gray-900 dark:text-white">المزامنة التلقائية</span>
            </div>
            <button
              onClick={() => setAppSettings(prev => ({ ...prev, autoSync: !prev.autoSync }))}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                appSettings.autoSync ? 'bg-indigo-600' : 'bg-gray-300 dark:bg-gray-600'
              }`}
            >
              <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                appSettings.autoSync ? 'translate-x-6' : 'translate-x-1'
              }`} />
            </button>
          </div>
        </div>
      </div>

      {/* إحصائيات الاستخدام */}
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl border border-gray-200 dark:border-gray-700 p-6">
        <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">إحصائيات الاستخدام</h2>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center p-4 bg-blue-50 dark:bg-blue-900/20 rounded-xl">
            <div className="text-2xl font-bold text-blue-600 mb-1">{sectionCounters.cart}</div>
            <p className="text-sm text-gray-600 dark:text-gray-400">عناصر السلة</p>
          </div>
          <div className="text-center p-4 bg-green-50 dark:bg-green-900/20 rounded-xl">
            <div className="text-2xl font-bold text-green-600 mb-1">{sectionCounters.orders}</div>
            <p className="text-sm text-gray-600 dark:text-gray-400">الطلبات</p>
          </div>
          <div className="text-center p-4 bg-purple-50 dark:bg-purple-900/20 rounded-xl">
            <div className="text-2xl font-bold text-purple-600 mb-1">{sectionCounters.favorites}</div>
            <p className="text-sm text-gray-600 dark:text-gray-400">المفضلة</p>
          </div>
          <div className="text-center p-4 bg-orange-50 dark:bg-orange-900/20 rounded-xl">
            <div className="text-2xl font-bold text-orange-600 mb-1">{sectionCounters.downloads}</div>
            <p className="text-sm text-gray-600 dark:text-gray-400">التحميلات</p>
          </div>
        </div>
      </div>

      {/* أزرار الإجراءات */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <button
          onClick={() => {
            setSystemStatus(prev => ({ ...prev, lastSync: new Date() }));
            alert('تم تحديث البيانات بنجاح!');
          }}
          className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white p-4 rounded-xl font-semibold hover:shadow-lg transition-all duration-300 flex items-center justify-center space-x-2 space-x-reverse"
        >
          <RefreshCw className="w-5 h-5" />
          <span>تحديث البيانات</span>
        </button>
        <button
          onClick={() => {
            if (confirm('هل أنت متأكد من إعادة تعيين جميع الإعدادات؟')) {
              setAppSettings({
                notifications: true,
                sound: true,
                language: 'ar',
                theme: 'auto',
                fontSize: 'medium',
                autoSync: true,
                offlineMode: false,
                dataUsage: 'normal',
                location: true,
                analytics: true
              });
              alert('تم إعادة تعيين الإعدادات بنجاح!');
            }
          }}
          className="bg-gradient-to-r from-red-500 to-pink-600 text-white p-4 rounded-xl font-semibold hover:shadow-lg transition-all duration-300 flex items-center justify-center space-x-2 space-x-reverse"
        >
          <Settings className="w-5 h-5" />
          <span>إعادة تعيين</span>
        </button>
      </div>
    </div>
  );

  const renderSection = () => {
    switch (currentSection) {
      case 'categories':
      case 'products':
        return <ShoppingSection section={currentSection} onAddToCart={addToCart} onBack={() => setCurrentSection('home')} />;
      case 'cart':
        return <Cart items={cartItems} onRemoveItem={removeFromCart} onBack={() => setCurrentSection('home')} />;
      case 'games':
        return <GamesSection onBack={() => setCurrentSection('home')} />;
      case 'tools':
        return <ToolsSection onBack={() => setCurrentSection('home')} />;
      case 'quran':
        return <QuranSection onBack={() => setCurrentSection('home')} />;
      case 'ai-library':
        return <AILibrary onBack={() => setCurrentSection('home')} />;
      case 'contact':
        return <ContactSection onBack={() => setCurrentSection('home')} />;
      case 'about':
        return <AboutSection onBack={() => setCurrentSection('home')} />;
      case 'store-links':
        return <StoreLinks onBack={() => setCurrentSection('home')} />;
      case 'special-orders':
        return <SpecialOrders onBack={() => setCurrentSection('home')} />;
      case 'settings':
        return <SettingsSection />;
      default:
        return <HomePage />;
    }
  };

  const HomePage = () => (
    <div className="space-y-8">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-br from-blue-600 via-purple-600 to-indigo-800 text-white p-8 rounded-2xl shadow-2xl overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="relative z-10 text-center">
          <div className="flex justify-center mb-4">
            <div className="bg-white/10 backdrop-blur-sm p-4 rounded-full">
              <Crown className="w-12 h-12 text-yellow-300" />
            </div>
          </div>
          <h1 className="text-4xl font-bold mb-2">تطبيق الوكيل</h1>
          <p className="text-xl opacity-90 mb-6">وكيلك الشخصي لكل ما تحتاجه</p>
          <div className="flex flex-wrap justify-center gap-4 text-sm">
            <span className="bg-white/20 px-3 py-1 rounded-full">متجر شامل</span>
            <span className="bg-white/20 px-3 py-1 rounded-full">ألعاب تفاعلية</span>
            <span className="bg-white/20 px-3 py-1 rounded-full">أدوات ذكية</span>
            <span className="bg-white/20 px-3 py-1 rounded-full">خدمات احترافية</span>
          </div>
        </div>
      </div>
      
      {/* إحصائيات سريعة */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-gray-800 p-4 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 text-center">
          <div className="text-2xl font-bold text-blue-600 mb-1">{sectionCounters.cart}</div>
          <p className="text-sm text-gray-600 dark:text-gray-400">في السلة</p>
        </div>
        <div className="bg-white dark:bg-gray-800 p-4 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 text-center">
          <div className="text-2xl font-bold text-green-600 mb-1">{sectionCounters.orders}</div>
          <p className="text-sm text-gray-600 dark:text-gray-400">طلباتي</p>
        </div>
        <div className="bg-white dark:bg-gray-800 p-4 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 text-center">
          <div className="text-2xl font-bold text-purple-600 mb-1">{sectionCounters.favorites}</div>
          <p className="text-sm text-gray-600 dark:text-gray-400">المفضلة</p>
        </div>
        <div className="bg-white dark:bg-gray-800 p-4 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 text-center">
          <div className="text-2xl font-bold text-orange-600 mb-1">{sectionCounters.notifications}</div>
          <p className="text-sm text-gray-600 dark:text-gray-400">إشعارات</p>
        </div>
      </div>

      {/* Main Services Grid */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6 text-center">
          الخدمات الرئيسية
        </h2>
        <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {mainSections.map((section) => (
            <button
              key={section.id}
              onClick={() => setCurrentSection(section.id as Section)}
              className="relative group bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 border border-gray-100 dark:border-gray-700"
            >
              {/* عدادات الأقسام */}
              {section.id === 'cart' && sectionCounters.cart > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-6 h-6 flex items-center justify-center font-bold">
                  {sectionCounters.cart}
                </span>
              )}
              {section.id === 'games' && (
                <span className="absolute -top-2 -right-2 bg-green-500 text-white text-xs rounded-full w-6 h-6 flex items-center justify-center font-bold">
                  {sectionCounters.games}
                </span>
              )}
              {section.id === 'tools' && (
                <span className="absolute -top-2 -right-2 bg-blue-500 text-white text-xs rounded-full w-6 h-6 flex items-center justify-center font-bold">
                  {sectionCounters.tools}
                </span>
              )}
              {section.id === 'quran' && (
                <span className="absolute -top-2 -right-2 bg-purple-500 text-white text-xs rounded-full w-6 h-6 flex items-center justify-center font-bold">
                  {sectionCounters.quran}
                </span>
              )}
              {section.id === 'ai-library' && (
                <span className="absolute -top-2 -right-2 bg-indigo-500 text-white text-xs rounded-full w-6 h-6 flex items-center justify-center font-bold">
                  {sectionCounters.ai}
                </span>
              )}
              
              <div className="flex flex-col items-center text-center space-y-3">
                <div className="bg-gradient-to-br from-blue-500 to-purple-600 p-3 rounded-full group-hover:scale-110 transition-transform duration-300">
                  <section.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="font-bold text-gray-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                  {section.title}
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
                  {section.description}
                </p>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Quick Access Tools */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6 text-center">
          وصول سريع
        </h2>
        <div className="grid grid-cols-4 lg:grid-cols-6 gap-4">
          {[
            { icon: Shield, title: 'VPN', color: 'bg-green-500' },
            { icon: StickyNote, title: 'المذكرات', color: 'bg-yellow-500' },
            { icon: Calculator, title: 'المحاسب', color: 'bg-blue-500' },
            { icon: Calendar, title: 'التقويم', color: 'bg-red-500' },
            { icon: Clock, title: 'المنبه', color: 'bg-purple-500' },
            { icon: Camera, title: 'المرآة', color: 'bg-pink-500' },
            { icon: Sparkles, title: 'المسبحة', color: 'bg-indigo-500' },
            { icon: Book, title: 'القرآن', color: 'bg-emerald-500' },
          ].map((tool, index) => (
            <button
              key={index}
              onClick={() => setCurrentSection('tools')}
              className="bg-white dark:bg-gray-800 p-4 rounded-xl shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 group"
            >
              <div className="flex flex-col items-center space-y-2">
                <div className={`${tool.color} p-2 rounded-full group-hover:scale-110 transition-transform duration-300`}>
                  <tool.icon className="w-5 h-5 text-white" />
                </div>
                <span className="text-xs font-medium text-gray-700 dark:text-gray-300 text-center">
                  {tool.title}
                </span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Information Section */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6 text-center">
          معلومات التطبيق
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {infoSections.map((section) => (
            <button
              key={section.id}
              onClick={() => setCurrentSection(section.id as Section)}
              className="relative bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100 dark:border-gray-700 group"
            >
              {/* عدادات خاصة */}
              {section.id === 'contact' && sectionCounters.messages > 0 && (
                <span className="absolute -top-2 -right-2 bg-green-500 text-white text-xs rounded-full w-6 h-6 flex items-center justify-center font-bold">
                  {sectionCounters.messages}
                </span>
              )}
              
              <div className="flex items-center space-x-4 space-x-reverse">
                <div className="bg-gradient-to-r from-gray-500 to-gray-600 p-3 rounded-full group-hover:scale-110 transition-transform duration-300">
                  <section.icon className="w-6 h-6 text-white" />
                </div>
                <div className="text-right">
                  <h3 className="font-bold text-gray-900 dark:text-white group-hover:text-gray-600 dark:group-hover:text-gray-400 transition-colors">
                    {section.title}
                  </h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {section.description}
                  </p>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'dark bg-gray-900' : 'bg-gray-50'}`} dir="rtl">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-lg border-b border-gray-200 dark:border-gray-700 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo and Title */}
            <div className="flex items-center space-x-4 space-x-reverse">
              <button
                onClick={() => setMenuOpen(!menuOpen)}
                className="lg:hidden p-2 rounded-md text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
              >
                {menuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
              <div className="flex items-center space-x-3 space-x-reverse">
                <div className="bg-gradient-to-br from-blue-600 to-purple-600 p-2 rounded-xl">
                  <Crown className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-900 dark:text-white">الوكيل</h1>
                  <p className="text-xs text-gray-600 dark:text-gray-400">وكيلك الشخصي</p>
                </div>
              </div>
            </div>

            {/* Date and Time */}
            <div className="hidden md:block">
              <DateTimeDisplay />
            </div>

            {/* Right Actions */}
            <div className="flex items-center space-x-4 space-x-reverse">
              {/* إشعارات */}
              <button
                onClick={() => alert(`لديك ${sectionCounters.notifications} إشعارات جديدة`)}
                className="relative p-2 text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
              >
                <Bell className="w-6 h-6" />
                {sectionCounters.notifications > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {sectionCounters.notifications}
                  </span>
                )}
              </button>

              {/* Cart Icon */}
              <button
                onClick={() => setCurrentSection('cart')}
                className="relative p-2 text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
              >
                <ShoppingCart className="w-6 h-6" />
                {cartItems.length > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {cartItems.length}
                  </span>
                )}
              </button>

              {/* Contact Icon */}
              <button
                onClick={() => setCurrentSection('contact')}
                className="relative p-2 text-gray-600 dark:text-gray-300 hover:text-green-600 dark:hover:text-green-400 transition-colors"
                title="تواصل معنا"
              >
                <MessageCircle className="w-6 h-6" />
                {sectionCounters.messages > 0 && (
                  <span className="absolute -top-1 -right-1 bg-green-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {sectionCounters.messages}
                  </span>
                )}
              </button>

              {/* Settings Icon */}
              <button
                onClick={() => setCurrentSection('settings')}
                className="p-2 text-gray-600 dark:text-gray-300 hover:text-purple-600 dark:hover:text-purple-400 transition-colors"
                title="الإعدادات"
              >
                <Settings className="w-6 h-6" />
              </button>

              {/* Dark Mode Toggle */}
              <button
                onClick={toggleDarkMode}
                className="p-2 text-gray-600 dark:text-gray-300 hover:text-yellow-600 dark:hover:text-yellow-400 transition-colors"
                title={darkMode ? 'الوضع النهاري' : 'الوضع الليلي'}
              >
                {darkMode ? <Sun className="w-6 h-6" /> : <Moon className="w-6 h-6" />}
              </button>

              {/* Home Button */}
              <button
                onClick={() => setCurrentSection('home')}
                className="p-2 text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                title="الصفحة الرئيسية"
              >
                <Home className="w-6 h-6" />
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {menuOpen && (
          <div className="lg:hidden bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700">
            <div className="px-4 py-2 space-y-1">
              {[...mainSections, ...infoSections].map((section) => (
                <button
                  key={section.id}
                  onClick={() => {
                    setCurrentSection(section.id as Section);
                    setMenuOpen(false);
                  }}
                  className="w-full flex items-center justify-between px-3 py-2 rounded-md text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                >
                  <div className="flex items-center space-x-3 space-x-reverse">
                    <section.icon className="w-5 h-5" />
                    <span>{section.title}</span>
                  </div>
                  {/* عدادات في القائمة المحمولة */}
                  {section.id === 'cart' && sectionCounters.cart > 0 && (
                    <span className="bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                      {sectionCounters.cart}
                    </span>
                  )}
                  {section.id === 'contact' && sectionCounters.messages > 0 && (
                    <span className="bg-green-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                      {sectionCounters.messages}
                    </span>
                  )}
                </button>
              ))}
            </div>
          </div>
        )}
      </header>

      <div className="flex">
        {/* Sidebar Navigation */}
        <Navigation
          currentSection={currentSection}
          onSectionChange={setCurrentSection}
          sections={[...mainSections, ...infoSections]}
        />

        {/* Main Content */}
        <main className="flex-1 p-4 lg:p-6 lg:mr-64">
          <div className="max-w-7xl mx-auto">
            {renderSection()}
          </div>
        </main>
      </div>

      {/* Floating Contact Button */}
      <button
        onClick={() => setCurrentSection('contact')}
        className="fixed bottom-6 left-6 bg-gradient-to-r from-green-500 to-emerald-600 text-white p-4 rounded-full shadow-2xl hover:shadow-3xl transform hover:scale-110 transition-all duration-300 z-40 relative"
        title="تواصل معنا"
      >
        <MessageCircle className="w-6 h-6" />
        {sectionCounters.messages > 0 && (
          <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-6 h-6 flex items-center justify-center font-bold">
            {sectionCounters.messages}
          </span>
        )}
      </button>
      
      {/* Bottom Navigation Bar - Mobile */}
      <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 shadow-2xl z-50 lg:hidden">
        <div className="flex items-center justify-around py-2">
          {/* Home Button */}
          <button
            onClick={() => setCurrentSection('home')}
            className={`flex flex-col items-center p-2 rounded-lg transition-all duration-300 ${
              currentSection === 'home' 
                ? 'text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/20' 
                : 'text-gray-600 dark:text-gray-400'
            }`}
            title="الرئيسية"
          >
            <Home className="w-5 h-5" />
            <span className="text-xs mt-1">الرئيسية</span>
          </button>

          {/* Settings Button */}
          <button
            onClick={() => setCurrentSection('settings')}
            className={`flex flex-col items-center p-2 rounded-lg transition-all duration-300 ${
              currentSection === 'settings' 
                ? 'text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-900/20' 
                : 'text-gray-600 dark:text-gray-400'
            }`}
            title="الإعدادات"
          >
            <Settings className="w-5 h-5" />
            <span className="text-xs mt-1">الإعدادات</span>
          </button>

          {/* Messages Button */}
          <button
            onClick={() => setCurrentSection('contact')}
            className={`relative flex flex-col items-center p-2 rounded-lg transition-all duration-300 ${
              currentSection === 'contact' 
                ? 'text-green-600 dark:text-green-400 bg-green-50 dark:bg-green-900/20' 
                : 'text-gray-600 dark:text-gray-400'
            }`}
            title="الرسائل"
          >
            <MessageCircle className="w-5 h-5" />
            <span className="text-xs mt-1">الرسائل</span>
            {sectionCounters.messages > 0 && (
              <span className="absolute -top-1 -right-1 bg-green-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center font-bold">
                {sectionCounters.messages}
              </span>
            )}
          </button>

          {/* Cart Button */}
          <button
            onClick={() => setCurrentSection('cart')}
            className={`relative flex flex-col items-center p-2 rounded-lg transition-all duration-300 ${
              currentSection === 'cart' 
                ? 'text-orange-600 dark:text-orange-400 bg-orange-50 dark:bg-orange-900/20' 
                : 'text-gray-600 dark:text-gray-400'
            }`}
            title="السلة"
          >
            <ShoppingCart className="w-5 h-5" />
            <span className="text-xs mt-1">السلة</span>
            {cartItems.length > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center font-bold">
                {cartItems.length}
              </span>
            )}
          </button>

          {/* Notifications Button */}
          <button
            onClick={() => {
              alert(`لديك ${sectionCounters.notifications} إشعارات جديدة:\n\n• رسالة جديدة من الدعم\n• تحديث في طلبك #1234\n• عرض خاص على المنتجات\n• تذكير: موعد التوصيل غداً`);
            }}
            className="relative flex flex-col items-center p-2 rounded-lg transition-all duration-300 text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400"
            title="الإشعارات"
          >
            <Bell className="w-5 h-5" />
            <span className="text-xs mt-1">الإشعارات</span>
            {sectionCounters.notifications > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center font-bold">
                {sectionCounters.notifications}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* حالة الاتصال */}
      {!systemStatus.online && (
        <div className="fixed top-20 left-4 right-4 bg-red-500 text-white p-3 rounded-lg shadow-lg z-50 flex items-center space-x-2 space-x-reverse">
          <WifiOff className="w-5 h-5" />
          <span>لا يوجد اتصال بالإنترنت</span>
        </div>
      )}

      {/* Spacer for bottom navigation on mobile */}
      <div className="h-16 lg:hidden"></div>
    </div>
  );
}

export default App;