import React from 'react';
import { 
  Crown, 
  Users, 
  Target, 
  Award, 
  Globe, 
  TrendingUp,
  Shield,
  Heart,
  Smartphone,
  Star
} from 'lucide-react';

interface AboutSectionProps {
  onBack: () => void;
}

const AboutSection: React.FC<AboutSectionProps> = ({ onBack }) => {
  const stats = [
    { icon: Users, label: 'المستخدمين النشطين', value: '500K+', color: 'text-blue-600' },
    { icon: Globe, label: 'الدول المخدومة', value: '15+', color: 'text-green-600' },
    { icon: Award, label: 'سنوات الخبرة', value: '8+', color: 'text-purple-600' },
    { icon: TrendingUp, label: 'معدل الرضا', value: '98%', color: 'text-orange-600' }
  ];

  const features = [
    {
      icon: Shield,
      title: 'الأمان والخصوصية',
      description: 'نحن نضمن حماية بياناتك وخصوصيتك بأعلى معايير الأمان'
    },
    {
      icon: Heart,
      title: 'خدمة متميزة',
      description: 'فريق دعم محترف متاح 24/7 لخدمتك وحل جميع استفساراتك'
    },
    {
      icon: Smartphone,
      title: 'تطبيق شامل',
      description: 'جميع الخدمات التي تحتاجها في تطبيق واحد سهل الاستخدام'
    }
  ];

  return (
    <div className="space-y-12">
      {/* Header with Back Button */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 space-x-reverse text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors bg-white dark:bg-gray-800 px-4 py-2 rounded-xl shadow-md hover:shadow-lg"
        >
          <span>← العودة للرئيسية</span>
        </button>
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">من نحن</h1>
        </div>
        <div></div>
      </div>
      
      {/* Hero Section */}
      <div className="text-center">
        <div className="flex justify-center mb-6">
          <div className="bg-gradient-to-br from-blue-600 to-purple-600 p-6 rounded-2xl shadow-2xl">
            <Crown className="w-16 h-16 text-white" />
          </div>
        </div>
        <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto leading-relaxed">
          تطبيق "الوكيل" هو منصة شاملة متعددة الخدمات تهدف إلى تقديم تجربة متكاملة 
          تجمع بين التسوق والترفيه والخدمات الذكية في مكان واحد
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <div
            key={index}
            className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 text-center transform hover:scale-105 transition-all duration-300"
          >
            <stat.icon className={`w-12 h-12 ${stat.color} mx-auto mb-3`} />
            <div className="text-3xl font-bold text-gray-900 dark:text-white mb-1">
              {stat.value}
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-400">
              {stat.label}
            </div>
          </div>
        ))}
      </div>

      {/* Mission & Vision */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-xl border border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-3 space-x-reverse mb-6">
            <Target className="w-8 h-8 text-blue-600 dark:text-blue-400" />
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white">رؤيتنا</h2>
          </div>
          <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
            أن نكون الوكيل الرقمي الأول في المنطقة، نقدم حلولاً شاملة ومبتكرة تلبي 
            جميع احتياجات المستخدمين اليومية من خلال منصة واحدة موثوقة وسهلة الاستخدام.
          </p>
        </div>

        <div className="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-xl border border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-3 space-x-reverse mb-6">
            <Star className="w-8 h-8 text-purple-600 dark:text-purple-400" />
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white">مهمتنا</h2>
          </div>
          <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
            تبسيط الحياة الرقمية للمستخدمين من خلال دمج الخدمات المتنوعة في تطبيق واحد، 
            مع ضمان أعلى معايير الجودة والأمان والخصوصية.
          </p>
        </div>
      </div>

      {/* Features */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-8 text-center">
          ما يميزنا
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 text-center group hover:shadow-xl transition-all duration-300"
            >
              <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                <feature.icon className="w-8 h-8 text-gray-600 dark:text-gray-400" />
              </div>
              <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-3">
                {feature.title}
              </h3>
              <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Team Section */}
      <div className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-gray-800 dark:to-gray-900 p-8 rounded-2xl border border-blue-200 dark:border-gray-700">
        <div className="text-center">
          <Users className="w-12 h-12 text-blue-600 dark:text-blue-400 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
            فريق العمل
          </h2>
          <p className="text-gray-700 dark:text-gray-300 max-w-2xl mx-auto leading-relaxed">
            فريقنا مكون من خبراء متخصصين في التكنولوجيا وخدمة العملاء، نعمل بشغف 
            لتقديم أفضل تجربة ممكنة لمستخدمينا الكرام.
          </p>
        </div>
      </div>
    </div>
  );
};

export default AboutSection;