import React, { useState, useEffect } from 'react';
import { 
  Shield, 
  StickyNote, 
  Calculator, 
  Calendar, 
  Clock, 
  Camera, 
  Sparkles,
  Plus,
  Save,
  Edit3,
  AlarmClock,
  Play,
  Pause,
  RotateCcw,
  Minus
} from 'lucide-react';

interface ToolsSectionProps {
  onBack: () => void;
}

const ToolsSection: React.FC<ToolsSectionProps> = ({ onBack }) => {
  const [selectedTool, setSelectedTool] = useState<string | null>(null);
  const [vpnConnected, setVpnConnected] = useState(false);
  const [notes, setNotes] = useState<any[]>([]);
  const [currentNote, setCurrentNote] = useState('');
  const [expenses, setExpenses] = useState<any[]>([]);
  const [tasbihCount, setTasbihCount] = useState(0);
  const [alarms, setAlarms] = useState<any[]>([]);
  const [cameraActive, setCameraActive] = useState(false);
  const [newExpense, setNewExpense] = useState({ amount: '', description: '', category: 'food' });
  const [budget, setBudget] = useState(5000);
  const [newAlarm, setNewAlarm] = useState({ time: '', label: '', repeat: false });
  const [currentTime, setCurrentTime] = useState(new Date());

  // Update time every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const tools = [
    {
      id: 'vpn',
      title: 'VPN داخلي',
      description: 'حماية خصوصيتك وتأمين اتصالك',
      icon: Shield,
      color: 'from-green-500 to-emerald-600'
    },
    {
      id: 'notes',
      title: 'المذكرات اليومية',
      description: 'اكتب وحفظ ملاحظاتك المهمة',
      icon: StickyNote,
      color: 'from-yellow-500 to-orange-500'
    },
    {
      id: 'calculator',
      title: 'المحاسب الشخصي',
      description: 'إدارة ميزانيتك ونفقاتك',
      icon: Calculator,
      color: 'from-blue-500 to-indigo-600'
    },
    {
      id: 'calendar',
      title: 'التقويم والجدولة',
      description: 'نظم مواعيدك ومهامك',
      icon: Calendar,
      color: 'from-red-500 to-pink-600'
    },
    {
      id: 'clock',
      title: 'الساعة والمنبه',
      description: 'ساعة عالمية ومنبهات',
      icon: Clock,
      color: 'from-purple-500 to-violet-600'
    },
    {
      id: 'mirror',
      title: 'المرآة',
      description: 'استخدم الكاميرا كمرآة',
      icon: Camera,
      color: 'from-pink-500 to-rose-600'
    },
    {
      id: 'tasbih',
      title: 'المسبحة الإلكترونية',
      description: 'سبحة رقمية للذكر والتسبيح',
      icon: Sparkles,
      color: 'from-indigo-500 to-purple-600'
    }
  ];

  const renderToolInterface = () => {
    switch (selectedTool) {
      case 'vpn':
        return (
          <div className="text-center space-y-6">
            <div className={`w-32 h-32 mx-auto rounded-full flex items-center justify-center ${
              vpnConnected ? 'bg-green-100 dark:bg-green-900' : 'bg-red-100 dark:bg-red-900'
            }`}>
              <Shield className={`w-16 h-16 ${
                vpnConnected ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
              }`} />
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                {vpnConnected ? 'متصل بأمان' : 'غير متصل'}
              </h3>
              <p className="text-gray-600 dark:text-gray-400">
                {vpnConnected ? 'الخادم: الرياض - السعودية' : 'اضغط للاتصال بـ VPN'}
              </p>
            </div>
            <button
              onClick={() => setVpnConnected(!vpnConnected)}
              className={`px-8 py-3 rounded-xl font-semibold transition-all duration-300 ${
                vpnConnected
                  ? 'bg-red-500 hover:bg-red-600 text-white'
                  : 'bg-green-500 hover:bg-green-600 text-white'
              }`}
            >
              {vpnConnected ? 'قطع الاتصال' : 'اتصال آمن'}
            </button>
          </div>
        );

      case 'notes':
        return (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">مذكراتي</h3>
              <button
                onClick={() => {
                  if (currentNote.trim()) {
                    setNotes([...notes, { id: Date.now(), text: currentNote, date: new Date() }]);
                    setCurrentNote('');
                  }
                }}
                className="flex items-center space-x-2 space-x-reverse bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>إضافة مذكرة</span>
              </button>
            </div>
            
            <textarea
              value={currentNote}
              onChange={(e) => setCurrentNote(e.target.value)}
              placeholder="اكتب مذكرتك هنا..."
              className="w-full h-32 p-4 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white resize-none"
            />
            
            <div className="space-y-3">
              {notes.map((note) => (
                <div key={note.id} className="bg-yellow-50 dark:bg-yellow-900/20 p-4 rounded-xl border border-yellow-200 dark:border-yellow-700">
                  <p className="text-gray-900 dark:text-white mb-2">{note.text}</p>
                  <p className="text-xs text-gray-600 dark:text-gray-400">
                    {note.date.toLocaleDateString('ar-EG')} - {note.date.toLocaleTimeString('ar-EG')}
                  </p>
                  <button
                    onClick={() => setNotes(notes.filter(n => n.id !== note.id))}
                    className="mt-2 text-red-500 hover:text-red-700 text-sm"
                  >
                    حذف
                  </button>
                </div>
              ))}
            </div>
          </div>
        );

      case 'calculator':
        const totalExpenses = expenses.reduce((sum, exp) => sum + parseFloat(exp.amount || 0), 0);
        const remainingBudget = budget - totalExpenses;
        
        return (
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">المحاسب الشخصي</h3>
              <div className="grid grid-cols-3 gap-4 mb-6">
                <div className="bg-blue-100 dark:bg-blue-900 p-4 rounded-xl text-center">
                  <p className="text-sm text-gray-600 dark:text-gray-400">الميزانية</p>
                  <p className="text-xl font-bold text-blue-600 dark:text-blue-400">{budget} ريال</p>
                </div>
                <div className="bg-red-100 dark:bg-red-900 p-4 rounded-xl text-center">
                  <p className="text-sm text-gray-600 dark:text-gray-400">المصروفات</p>
                  <p className="text-xl font-bold text-red-600 dark:text-red-400">{totalExpenses} ريال</p>
                </div>
                <div className="bg-green-100 dark:bg-green-900 p-4 rounded-xl text-center">
                  <p className="text-sm text-gray-600 dark:text-gray-400">المتبقي</p>
                  <p className="text-xl font-bold text-green-600 dark:text-green-400">{remainingBudget} ريال</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white dark:bg-gray-700 p-4 rounded-xl">
              <h4 className="font-bold text-gray-900 dark:text-white mb-4">إضافة مصروف جديد</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <input
                  type="number"
                  placeholder="المبلغ"
                  value={newExpense.amount}
                  onChange={(e) => setNewExpense({...newExpense, amount: e.target.value})}
                  className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                />
                <input
                  type="text"
                  placeholder="الوصف"
                  value={newExpense.description}
                  onChange={(e) => setNewExpense({...newExpense, description: e.target.value})}
                  className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                />
                <select
                  value={newExpense.category}
                  onChange={(e) => setNewExpense({...newExpense, category: e.target.value})}
                  className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                >
                  <option value="food">طعام</option>
                  <option value="transport">مواصلات</option>
                  <option value="shopping">تسوق</option>
                  <option value="bills">فواتير</option>
                  <option value="other">أخرى</option>
                </select>
              </div>
              <button
                onClick={() => {
                  if (newExpense.amount && newExpense.description) {
                    setExpenses([...expenses, { ...newExpense, id: Date.now(), date: new Date() }]);
                    setNewExpense({ amount: '', description: '', category: 'food' });
                  }
                }}
                className="mt-4 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
              >
                إضافة مصروف
              </button>
            </div>
            
            <div className="space-y-3">
              {expenses.map((expense) => (
                <div key={expense.id} className="bg-gray-50 dark:bg-gray-700 p-4 rounded-xl flex justify-between items-center">
                  <div>
                    <p className="font-semibold text-gray-900 dark:text-white">{expense.description}</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{expense.category}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-red-600 dark:text-red-400">{expense.amount} ريال</p>
                    <button
                      onClick={() => setExpenses(expenses.filter(e => e.id !== expense.id))}
                      className="text-red-500 hover:text-red-700 text-sm"
                    >
                      حذف
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );

      case 'clock':
        return (
          <div className="space-y-6">
            <div className="text-center">
              <div className="bg-gradient-to-br from-purple-500 to-indigo-600 text-white p-8 rounded-2xl shadow-2xl">
                <h3 className="text-2xl font-bold mb-4">الساعة العالمية</h3>
                <div className="text-6xl font-bold mb-2">
                  {currentTime.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}
                </div>
                <div className="text-lg opacity-90">
                  {currentTime.toLocaleDateString('ar-EG', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                </div>
              </div>
            </div>
            
            <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg">
              <h4 className="font-bold text-gray-900 dark:text-white mb-4">إضافة منبه جديد</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input
                  type="time"
                  value={newAlarm.time}
                  onChange={(e) => setNewAlarm({...newAlarm, time: e.target.value})}
                  className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                />
                <input
                  type="text"
                  placeholder="تسمية المنبه"
                  value={newAlarm.label}
                  onChange={(e) => setNewAlarm({...newAlarm, label: e.target.value})}
                  className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                />
              </div>
              <div className="mt-4 flex items-center space-x-2 space-x-reverse">
                <input
                  type="checkbox"
                  checked={newAlarm.repeat}
                  onChange={(e) => setNewAlarm({...newAlarm, repeat: e.target.checked})}
                  className="rounded"
                />
                <label className="text-gray-700 dark:text-gray-300">تكرار يومي</label>
              </div>
              <button
                onClick={() => {
                  if (newAlarm.time && newAlarm.label) {
                    setAlarms([...alarms, { ...newAlarm, id: Date.now(), active: true }]);
                    setNewAlarm({ time: '', label: '', repeat: false });
                  }
                }}
                className="mt-4 bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors"
              >
                إضافة منبه
              </button>
            </div>
            
            <div className="space-y-3">
              {alarms.map((alarm) => (
                <div key={alarm.id} className="bg-gray-50 dark:bg-gray-700 p-4 rounded-xl flex justify-between items-center">
                  <div>
                    <p className="font-bold text-gray-900 dark:text-white text-xl">{alarm.time}</p>
                    <p className="text-gray-600 dark:text-gray-400">{alarm.label}</p>
                    {alarm.repeat && <p className="text-sm text-blue-600 dark:text-blue-400">يومي</p>}
                  </div>
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <button
                      onClick={() => setAlarms(alarms.map(a => a.id === alarm.id ? {...a, active: !a.active} : a))}
                      className={`px-3 py-1 rounded-full text-sm ${alarm.active ? 'bg-green-500 text-white' : 'bg-gray-300 text-gray-700'}`}
                    >
                      {alarm.active ? 'مفعل' : 'معطل'}
                    </button>
                    <button
                      onClick={() => setAlarms(alarms.filter(a => a.id !== alarm.id))}
                      className="text-red-500 hover:text-red-700"
                    >
                      حذف
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );

      case 'tasbih':
        return (
          <div className="text-center space-y-8 max-w-md mx-auto">
            <div className="w-64 h-64 mx-auto bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full flex items-center justify-center shadow-2xl cursor-pointer transform hover:scale-105 transition-all duration-300"
                 onClick={() => setTasbihCount(prev => prev + 1)}>
              <div className="text-center text-white">
                <Sparkles className="w-16 h-16 mx-auto mb-4" />
                <div className="text-6xl font-bold mb-2">{tasbihCount}</div>
                <div className="text-lg opacity-90">تسبيحة</div>
              </div>
            </div>
            
            <p className="text-gray-600 dark:text-gray-400 text-sm">
              اضغط على الدائرة أو الأزرار أدناه للتسبيح
            </p>
            
            <div className="flex justify-center space-x-4 space-x-reverse">
              <button
                onClick={() => setTasbihCount(prev => prev + 1)}
                className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-3 rounded-xl text-base font-semibold hover:shadow-lg transform hover:scale-105 transition-all duration-300"
              >
                + تسبيح
              </button>
              <button
                onClick={() => setTasbihCount(0)}
                className="bg-gray-500 text-white px-6 py-3 rounded-xl font-semibold hover:bg-gray-600 transition-colors"
              >
                إعادة ضبط
              </button>
            </div>
            
            {/* Counter milestones */}
            <div className="grid grid-cols-3 gap-2 text-xs">
              <div className={`p-2 rounded-lg text-center ${tasbihCount >= 33 ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400'}`}>
                <div className="font-bold">33</div>
                <div>سبحان الله</div>
              </div>
              <div className={`p-2 rounded-lg text-center ${tasbihCount >= 66 ? 'bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200' : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400'}`}>
                <div className="font-bold">66</div>
                <div>الحمد لله</div>
              </div>
              <div className={`p-2 rounded-lg text-center ${tasbihCount >= 99 ? 'bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-200' : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400'}`}>
                <div className="font-bold">99</div>
                <div>الله أكبر</div>
              </div>
            </div>
            
            <div className="bg-gray-50 dark:bg-gray-700 p-6 rounded-xl">
              <h4 className="font-semibold text-gray-900 dark:text-white mb-2">أذكار مقترحة</h4>
              <div className="space-y-3">
                {[
                  { text: 'سبحان الله', count: 33 },
                  { text: 'الحمد لله', count: 33 },
                  { text: 'الله أكبر', count: 34 },
                  { text: 'لا إله إلا الله', count: 100 },
                  { text: 'استغفر الله', count: 100 },
                  { text: 'اللهم صل على محمد', count: 100 }
                ].map((dhikr, index) => (
                  <button
                    key={index}
                    onClick={() => setTasbihCount(0)}
                    className="w-full text-right p-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-600 rounded-lg transition-colors flex justify-between items-center"
                  >
                    <span>{dhikr.text}</span>
                    <span className="text-xs bg-gray-200 dark:bg-gray-600 px-2 py-1 rounded-full">{dhikr.count}×</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        );

      case 'mirror':
        return (
          <div className="text-center space-y-6">
            <div className="aspect-video bg-gray-900 rounded-2xl flex items-center justify-center relative overflow-hidden">
              {cameraActive ? (
                <div className="text-white">
                  <Camera className="w-16 h-16 mx-auto mb-4" />
                  <p>كاميرا نشطة - المرآة تعمل</p>
                </div>
              ) : (
                <div className="text-white text-center">
                  <Camera className="w-16 h-16 mx-auto mb-4" />
                  <h3 className="text-xl font-bold mb-2">المرآة الذكية</h3>
                  <p className="text-gray-300">اضغط لتفعيل الكاميرا</p>
                </div>
              )}
            </div>
            <button
              onClick={() => setCameraActive(!cameraActive)}
              className={`px-8 py-3 rounded-xl font-semibold transition-all duration-300 ${
                cameraActive
                  ? 'bg-red-500 hover:bg-red-600 text-white'
                  : 'bg-blue-500 hover:bg-blue-600 text-white'
              }`}
            >
              {cameraActive ? 'إيقاف المرآة' : 'تشغيل المرآة'}
            </button>
          </div>
        );

      default:
        return null;
    }
  };

  if (selectedTool) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <button
            onClick={() => setSelectedTool(null)}
            className="flex items-center space-x-2 space-x-reverse text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors bg-white dark:bg-gray-800 px-4 py-2 rounded-xl shadow-md hover:shadow-lg"
          >
            <span>← العودة للأدوات</span>
          </button>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl border border-gray-200 dark:border-gray-700 p-8">
          {renderToolInterface()}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header with Back Button */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 space-x-reverse text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors bg-white dark:bg-gray-800 px-4 py-2 rounded-xl shadow-md hover:shadow-lg"
        >
          <span>← العودة للرئيسية</span>
        </button>
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">الأدوات الذكية</h1>
        </div>
        <div></div>
      </div>
      
      <div className="text-center">
        <p className="text-gray-600 dark:text-gray-400">
          مجموعة شاملة من الأدوات الاحترافية لحياتك اليومية
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {tools.map((tool) => (
          <div
            key={tool.id}
            onClick={() => setSelectedTool(tool.id)}
            className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-200 dark:border-gray-700 overflow-hidden group cursor-pointer"
          >
            <div className={`bg-gradient-to-br ${tool.color} p-6 text-white relative`}>
              <tool.icon className="w-12 h-12 mb-4 group-hover:scale-110 transition-transform duration-300" />
              <h3 className="text-xl font-bold mb-2">{tool.title}</h3>
            </div>
            
            <div className="p-6">
              <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                {tool.description}
              </p>
              <button 
                onClick={() => setSelectedTool(tool.id)}
                className="mt-4 w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-2 rounded-xl hover:shadow-lg transition-all duration-300"
              >
                فتح الأداة
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ToolsSection;