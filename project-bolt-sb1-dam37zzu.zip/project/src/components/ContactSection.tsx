import React, { useState } from 'react';
import { 
  Phone, 
  Mail, 
  MessageCircle, 
  MapPin, 
  Clock, 
  Send,
  Headphones,
  Globe,
  Smartphone
} from 'lucide-react';

interface ContactSectionProps {
  onBack: () => void;
}

const ContactSection: React.FC<ContactSectionProps> = ({ onBack }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitStatus('success');
      setFormData({ name: '', email: '', subject: '', message: '' });
      
      // Reset status after 3 seconds
      setTimeout(() => setSubmitStatus('idle'), 3000);
    }, 2000);
  };

  const contactMethods = [
    {
      icon: Phone,
      title: 'الهاتف',
      value: '+966 11 234 5678',
      description: 'متاح 24/7',
      color: 'from-green-500 to-emerald-600'
    },
    {
      icon: Mail,
      title: 'البريد الإلكتروني',
      value: 'support@alwakeel.app',
      description: 'رد خلال 24 ساعة',
      color: 'from-blue-500 to-indigo-600'
    },
    {
      icon: MessageCircle,
      title: 'الدردشة المباشرة',
      value: 'دعم فوري',
      description: 'متاح من 8 ص إلى 12 م',
      color: 'from-purple-500 to-violet-600'
    },
    {
      icon: MapPin,
      title: 'العنوان',
      value: 'الرياض، المملكة العربية السعودية',
      description: 'المقر الرئيسي',
      color: 'from-red-500 to-pink-600'
    }
  ];

  return (
    <div className="space-y-8">
      {/* Header with Back Button */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 space-x-reverse text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors bg-white dark:bg-gray-800 px-4 py-2 rounded-xl shadow-md hover:shadow-lg"
        >
          <span>← العودة للرئيسية</span>
        </button>
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">تواصل معنا</h1>
        </div>
        <div></div>
      </div>
      
      <div className="text-center">
        <p className="text-gray-600 dark:text-gray-400">
          نحن هنا لمساعدتك في أي استفسار أو مشكلة
        </p>
      </div>

      {/* Contact Methods */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {contactMethods.map((method, index) => (
          <div
            key={index}
            onClick={() => {
              if (method.title === 'الهاتف') {
                window.open('tel:+966112345678');
              } else if (method.title === 'البريد الإلكتروني') {
                window.open('mailto:support@alwakeel.app');
              } else if (method.title === 'الدردشة المباشرة') {
                // Open chat widget
                alert('سيتم فتح نافذة الدردشة المباشرة');
              }
            }}
            className="bg-white dark:bg-gray-800 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 border border-gray-200 dark:border-gray-700 overflow-hidden group cursor-pointer"
          >
            <div className={`bg-gradient-to-br ${method.color} p-4 text-white`}>
              <method.icon className="w-8 h-8 mb-2 group-hover:scale-110 transition-transform duration-300" />
              <h3 className="font-bold">{method.title}</h3>
            </div>
            <div className="p-4">
              <p className="font-semibold text-gray-900 dark:text-white text-sm mb-1">
                {method.value}
              </p>
              <p className="text-xs text-gray-600 dark:text-gray-400">
                {method.description}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* Contact Form */}
      <div className="max-w-2xl mx-auto">
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl border border-gray-200 dark:border-gray-700 p-8">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6 text-center">
            أرسل لنا رسالة
          </h2>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  الاسم الكامل
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  البريد الإلكتروني
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  required
                />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                موضوع الرسالة
              </label>
              <input
                type="text"
                value={formData.subject}
                onChange={(e) => setFormData({...formData, subject: e.target.value})}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                الرسالة
              </label>
              <textarea
                value={formData.message}
                onChange={(e) => setFormData({...formData, message: e.target.value})}
                rows={6}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white resize-none"
                required
              />
            </div>
            
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-4 rounded-xl font-semibold hover:shadow-lg transform hover:scale-105 transition-all duration-300 flex items-center justify-center space-x-2 space-x-reverse"
            >
              {isSubmitting ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  <span>جاري الإرسال...</span>
                </>
              ) : (
                <>
                  <Send className="w-5 h-5" />
                  <span>إرسال الرسالة</span>
                </>
              )}
            </button>
            
            {submitStatus === 'success' && (
              <div className="mt-4 p-3 bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 rounded-lg text-center">
                تم إرسال رسالتك بنجاح! سنتواصل معك قريباً.
              </div>
            )}
          </form>
        </div>
      </div>

      {/* Quick Support */}
      <div className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 p-6 rounded-2xl border border-green-200 dark:border-green-700">
        <div className="text-center">
          <Headphones className="w-12 h-12 text-green-600 dark:text-green-400 mx-auto mb-4" />
          <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">دعم فوري</h3>
          <p className="text-gray-700 dark:text-gray-300 mb-4">
            هل تحتاج مساعدة عاجلة؟ تواصل معنا مباشرة
          </p>
          <div className="flex justify-center space-x-4 space-x-reverse">
            <button className="bg-green-600 text-white px-6 py-3 rounded-xl hover:bg-green-700 transition-colors flex items-center space-x-2 space-x-reverse">
              onClick={() => window.open('tel:+966112345678')}
              <Phone className="w-4 h-4" />
              <span>اتصال مباشر</span>
            </button>
            <button className="bg-blue-600 text-white px-6 py-3 rounded-xl hover:bg-blue-700 transition-colors flex items-center space-x-2 space-x-reverse">
              onClick={() => alert('سيتم فتح نافذة الدردشة المباشرة')}
              <MessageCircle className="w-4 h-4" />
              <span>دردشة فورية</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactSection;