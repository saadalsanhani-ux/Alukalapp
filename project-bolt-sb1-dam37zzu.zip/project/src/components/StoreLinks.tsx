import React from 'react';
import { Download, Smartphone, QrCode, Share2, ExternalLink, Shield, Zap, Users } from 'lucide-react';

interface StoreLinksProps {
  onBack: () => void;
}

const StoreLinks: React.FC<StoreLinksProps> = ({ onBack }) => {
  const storeLinks = [
    {
      store: 'App Store',
      platform: 'iOS',
      icon: '🍎',
      description: 'للأيفون والأيباد',
      color: 'from-gray-800 to-black',
      users: '2M+ تحميل',
      rating: '4.8 ⭐'
    },
    {
      store: 'Google Play',
      platform: 'Android',
      icon: '📱',
      description: 'لجميع أجهزة الأندرويد',
      color: 'from-green-600 to-green-800',
      users: '5M+ تحميل',
      rating: '4.7 ⭐'
    },
    {
      store: 'Huawei AppGallery',
      platform: 'HarmonyOS',
      icon: '🔥',
      description: 'لأجهزة هواوي',
      color: 'from-red-600 to-red-800',
      users: '500K+ تحميل',
      rating: '4.6 ⭐'
    },
    {
      store: 'Samsung Galaxy Store',
      platform: 'Samsung',
      icon: '⭐',
      description: 'لأجهزة سامسونج',
      color: 'from-blue-600 to-blue-800',
      users: '1M+ تحميل',
      rating: '4.7 ⭐'
    }
  ];

  const features = [
    {
      icon: Shield,
      title: 'أمان متقدم',
      description: 'حماية كاملة لبياناتك وخصوصيتك'
    },
    {
      icon: Zap,
      title: 'أداء سريع',
      description: 'تجربة سلسة وسريعة في جميع الأوقات'
    },
    {
      icon: Users,
      title: 'دعم 24/7',
      description: 'فريق دعم متاح في أي وقت لمساعدتك'
    }
  ];

  return (
    <div className="space-y-8">
      {/* Header with Back Button */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 space-x-reverse text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors bg-white dark:bg-gray-800 px-4 py-2 rounded-xl shadow-md hover:shadow-lg"
        >
          <span>← العودة للرئيسية</span>
        </button>
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">تحميل التطبيق</h1>
        </div>
        <div></div>
      </div>
      
      <div className="text-center">
        <div className="flex justify-center mb-6">
          <div className="bg-gradient-to-br from-blue-600 to-purple-600 p-6 rounded-2xl shadow-2xl">
            <Download className="w-16 h-16 text-white" />
          </div>
        </div>
        <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
          حمّل تطبيق الوكيل على جهازك واستمتع بجميع الخدمات في أي وقت ومكان
        </p>
      </div>

      {/* Store Links Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {storeLinks.map((link, index) => (
          <div
            key={index}
            className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-200 dark:border-gray-700 overflow-hidden group cursor-pointer"
          >
            <div className={`bg-gradient-to-br ${link.color} p-6 text-white relative`}>
              <div className="text-4xl mb-4">{link.icon}</div>
              <h3 className="text-xl font-bold mb-2">{link.store}</h3>
              <p className="text-white/90 text-sm">{link.description}</p>
            </div>
            
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">{link.users}</p>
                  <p className="text-sm font-semibold text-gray-900 dark:text-white">{link.rating}</p>
                </div>
                <div className="text-2xl font-bold text-gray-400 dark:text-gray-500">
                  {link.platform}
                </div>
              </div>
              
              <button className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-3 rounded-xl font-semibold hover:shadow-lg transform hover:scale-105 transition-all duration-300 flex items-center justify-center space-x-2 space-x-reverse">
                <ExternalLink className="w-4 h-4" />
                <span>تحميل الآن</span>
              </button>
              <div className="mt-3 text-center">
                <span className="text-xs text-gray-500 dark:text-gray-400">
                  متوافق مع {link.platform}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* QR Code Section */}
      <div className="bg-gradient-to-r from-gray-50 to-blue-50 dark:from-gray-800 dark:to-gray-900 p-8 rounded-2xl border border-gray-200 dark:border-gray-700">
        <div className="text-center">
          <QrCode className="w-16 h-16 text-gray-600 dark:text-gray-400 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
            رمز QR للتحميل السريع
          </h2>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            امسح الرمز بكاميرا هاتفك للانتقال مباشرة لصفحة التحميل
          </p>
          
          {/* QR Code Placeholder */}
          <div className="bg-white dark:bg-gray-700 p-8 rounded-xl shadow-lg inline-block border border-gray-200 dark:border-gray-600">
            <div className="w-48 h-48 bg-gray-100 dark:bg-gray-600 rounded-lg flex items-center justify-center">
              <QrCode className="w-24 h-24 text-gray-400" />
            </div>
          </div>
          
          <div className="mt-6 flex justify-center space-x-4 space-x-reverse">
            <button 
              onClick={() => {
                if (navigator.share) {
                  navigator.share({
                    title: 'تطبيق الوكيل',
                    text: 'حمّل تطبيق الوكيل الآن',
                    url: window.location.href
                  });
                } else {
                  navigator.clipboard.writeText(window.location.href);
                  alert('تم نسخ الرابط');
                }
              }}
              className="flex items-center space-x-2 space-x-reverse bg-blue-600 text-white px-6 py-3 rounded-xl hover:bg-blue-700 transition-colors">
              <Share2 className="w-4 h-4" />
              <span>مشاركة الرابط</span>
            </button>
          </div>
        </div>
      </div>

      {/* App Features */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-8 text-center">
          مميزات التطبيق
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 text-center hover:shadow-xl transition-all duration-300"
            >
              <div className="bg-blue-100 dark:bg-blue-900 p-4 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <feature.icon className="w-8 h-8 text-blue-600 dark:text-blue-400" />
              </div>
              <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-3">
                {feature.title}
              </h3>
              <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Call to Action */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-8 rounded-2xl shadow-2xl text-center">
        <Smartphone className="w-12 h-12 mx-auto mb-4" />
        <h2 className="text-2xl font-bold mb-4">جرب التطبيق الآن</h2>
        <p className="text-white/90 mb-6 max-w-2xl mx-auto">
          انضم إلى ملايين المستخدمين الذين يثقون في تطبيق الوكيل لتلبية احتياجاتهم اليومية
        </p>
        <button 
          onClick={() => {
            // Detect device and redirect to appropriate store
            const userAgent = navigator.userAgent;
            if (/iPad|iPhone|iPod/.test(userAgent)) {
              window.open('https://apps.apple.com/app/alwakeel', '_blank');
            } else if (/Android/.test(userAgent)) {
              window.open('https://play.google.com/store/apps/details?id=com.alwakeel.app', '_blank');
            } else {
              alert('يرجى تحميل التطبيق من متجر التطبيقات المناسب لجهازك');
            }
          }}
          className="bg-white text-blue-600 px-8 py-4 rounded-xl font-bold hover:shadow-lg transform hover:scale-105 transition-all duration-300">
          تحميل مجاني
        </button>
      </div>
    </div>
  );
};

export default StoreLinks;