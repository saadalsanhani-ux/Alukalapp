import React, { useState } from 'react';
import { Book, Play, Pause, Volume2, BookOpen, Search, Star, Heart } from 'lucide-react';

interface QuranSectionProps {
  onBack: () => void;
}

const QuranSection: React.FC<QuranSectionProps> = ({ onBack }) => {
  const [selectedReciter, setSelectedReciter] = useState<string | null>(null);
  const [selectedSurah, setSelectedSurah] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [favorites, setFavorites] = useState<string[]>([]);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);

  const reciters = [
    // قراء السعودية
    { id: 'sudais', name: 'عبد الرحمن السديس', country: 'السعودية', specialty: 'إمام الحرم المكي' },
    { id: 'shuraim', name: 'سعود الشريم', country: 'السعودية', specialty: 'إمام الحرم المكي' },
    { id: 'ghamdi', name: 'سعد الغامدي', country: 'السعودية', specialty: 'تلاوة مجودة' },
    { id: 'ajmi', name: 'أحمد العجمي', country: 'السعودية', specialty: 'تلاوة عذبة' },
    { id: 'hosary', name: 'محمود خليل الحصري', country: 'السعودية', specialty: 'شيخ المقرئين' },
    { id: 'maher', name: 'ماهر المعيقلي', country: 'السعودية', specialty: 'إمام الحرم المكي' },
    { id: 'juhany', name: 'عبد الله الجهني', country: 'السعودية', specialty: 'تلاوة خاشعة' },
    { id: 'dosari', name: 'عبد الله الدوسري', country: 'السعودية', specialty: 'صوت مميز' },
    { id: 'shehata', name: 'أبو بكر الشاطري', country: 'السعودية', specialty: 'تلاوة حزينة' },
    { id: 'budair', name: 'عبد الله بصفر', country: 'السعودية', specialty: 'تجويد متقن' },
    
    // قراء مصر
    { id: 'minshawi', name: 'محمد صديق المنشاوي', country: 'مصر', specialty: 'التجويد الكلاسيكي' },
    { id: 'tablawi', name: 'محمد محمود الطبلاوي', country: 'مصر', specialty: 'الأداء المميز' },
    { id: 'abdulsamad', name: 'عبد الباسط عبد الصمد', country: 'مصر', specialty: 'الصوت الذهبي' },
    { id: 'mustafa', name: 'مصطفى إسماعيل', country: 'مصر', specialty: 'عميد القراء' },
    { id: 'shahat', name: 'محمد محمود الشحات أنور', country: 'مصر', specialty: 'تلاوة مؤثرة' },
    { id: 'omar', name: 'عمر القزابري', country: 'مصر', specialty: 'أداء متميز' },
    { id: 'hussary', name: 'محمود خليل الحصري', country: 'مصر', specialty: 'شيخ المقرئين' },
    { id: 'basfar', name: 'عبد الله بصفر', country: 'مصر', specialty: 'تجويد عالي' },
    
    // قراء الشام
    { id: 'fares', name: 'فارس عباد', country: 'سوريا', specialty: 'تلاوة حزينة' },
    { id: 'qari', name: 'عبد الرشيد صوفي', country: 'سوريا', specialty: 'أداء متميز' },
    { id: 'kurdi', name: 'أحمد الكردي', country: 'سوريا', specialty: 'تلاوة شامية' },
    { id: 'shatri', name: 'أبو بكر الشاطري', country: 'سوريا', specialty: 'صوت عذب' },
    { id: 'damascus', name: 'محمد الدمشقي', country: 'سوريا', specialty: 'التراث الشامي' },
    
    // قراء اليمن
    { id: 'yamani1', name: 'فضل الله عبادي', country: 'اليمن', specialty: 'التلاوة اليمنية الأصيلة' },
    { id: 'yamani2', name: 'أحمد الحداد', country: 'اليمن', specialty: 'الأداء التقليدي' },
    { id: 'yamani3', name: 'محمد العريقي', country: 'اليمن', specialty: 'تلاوة مؤثرة' },
    { id: 'yamani4', name: 'عبدالله الجوفي', country: 'اليمن', specialty: 'صوت عذب' },
    { id: 'yamani5', name: 'حسان الشيباني', country: 'اليمن', specialty: 'تجويد متقن' },
    { id: 'yamani6', name: 'صالح الصنعاني', country: 'اليمن', specialty: 'التراث اليمني' },
    { id: 'yamani7', name: 'محمد الحضرمي', country: 'اليمن', specialty: 'أسلوب حضرمي' },
    { id: 'yamani8', name: 'أحمد التعزي', country: 'اليمن', specialty: 'تلاوة تعزية' },
    { id: 'yamani9', name: 'عبدالرحمن الإبي', country: 'اليمن', specialty: 'صوت يمني أصيل' },
    { id: 'yamani10', name: 'فيصل الزبيدي', country: 'اليمن', specialty: 'تجويد يمني' },
    { id: 'yamani11', name: 'محمد الأهدل', country: 'اليمن', specialty: 'التلاوة التهامية' },
    { id: 'yamani12', name: 'عبدالله المحويتي', country: 'اليمن', specialty: 'أسلوب محويتي' },
    { id: 'yamani13', name: 'أحمد الشرعبي', country: 'اليمن', specialty: 'تراث شرعبي' },
    { id: 'yamani14', name: 'صالح الحوثي', country: 'اليمن', specialty: 'تلاوة صعدية' },
    { id: 'yamani15', name: 'محمد الوادعي', country: 'اليمن', specialty: 'المدرسة الوادعية' },
    
    // قراء من دول أخرى
    { id: 'naeenaa', name: 'أحمد نعينع', country: 'الإمارات', specialty: 'تلاوة هادئة' },
    { id: 'afasy', name: 'مشاري راشد العفاسي', country: 'الكويت', specialty: 'صوت مميز' },
    { id: 'sofi', name: 'عبد الرشيد صوفي', country: 'المغرب', specialty: 'الأداء المغربي' },
    { id: 'hamdi', name: 'محمد الطيب حمدي', country: 'تونس', specialty: 'التلاوة التونسية' },
    { id: 'algeria1', name: 'عبد الرحمن مسعد', country: 'الجزائر', specialty: 'تلاوة جزائرية' },
    { id: 'jordan1', name: 'أحمد الطرابلسي', country: 'الأردن', specialty: 'التلاوة الأردنية' },
    { id: 'lebanon1', name: 'محمد رشاد الشريف', country: 'لبنان', specialty: 'الأسلوب اللبناني' },
    { id: 'palestine1', name: 'عبد الباسط هاشم', country: 'فلسطين', specialty: 'التراث الفلسطيني' },
    { id: 'libya1', name: 'صادق الغرياني', country: 'ليبيا', specialty: 'التلاوة الليبية' },
    { id: 'sudan1', name: 'البراء العويد', country: 'السودان', specialty: 'الأسلوب السوداني' },
    { id: 'iraq1', name: 'أحمد الحذيفي', country: 'العراق', specialty: 'التلاوة العراقية' },
    { id: 'oman1', name: 'أحمد الحارثي', country: 'عمان', specialty: 'التراث العماني' },
    { id: 'bahrain1', name: 'راشد الماجد', country: 'البحرين', specialty: 'الأسلوب البحريني' },
    { id: 'qatar1', name: 'فارس عباد', country: 'قطر', specialty: 'التلاوة القطرية' },
    
    // قراء إضافيون من مختلف البلدان
    { id: 'turkey1', name: 'محمد صديق المنشاوي', country: 'تركيا', specialty: 'التلاوة التركية' },
    { id: 'indonesia1', name: 'مزمل حسين', country: 'إندونيسيا', specialty: 'الأسلوب الآسيوي' },
    { id: 'malaysia1', name: 'قاري وحيد', country: 'ماليزيا', specialty: 'التلاوة الماليزية' },
    { id: 'pakistan1', name: 'قاري عبد الباسط', country: 'باكستان', specialty: 'الأسلوب الباكستاني' },
    { id: 'india1', name: 'قاري محمد طيب', country: 'الهند', specialty: 'التلاوة الهندية' },
    { id: 'bangladesh1', name: 'قاري إبراهيم', country: 'بنغلاديش', specialty: 'الأسلوب البنغالي' },
    { id: 'nigeria1', name: 'الشيخ جعفر', country: 'نيجيريا', specialty: 'التلاوة الأفريقية' },
    { id: 'senegal1', name: 'الشيخ أحمد', country: 'السنغال', specialty: 'الأسلوب السنغالي' },
    { id: 'morocco2', name: 'أحمد الطيب', country: 'المغرب', specialty: 'المدرسة المغربية' },
    { id: 'tunisia2', name: 'محمد الهادي', country: 'تونس', specialty: 'التراث التونسي' },
    { id: 'algeria2', name: 'عبد الحميد بن باديس', country: 'الجزائر', specialty: 'المدرسة الجزائرية' },
    { id: 'mauritania1', name: 'الشيخ ولد الددو', country: 'موريتانيا', specialty: 'التلاوة الموريتانية' },
    { id: 'somalia1', name: 'عبد الرشيد علي', country: 'الصومال', specialty: 'الأسلوب الصومالي' },
    { id: 'ethiopia1', name: 'أحمد نجاشي', country: 'إثيوبيا', specialty: 'التلاوة الإثيوبية' },
    { id: 'usa1', name: 'عبد الناصر جنكو', country: 'أمريكا', specialty: 'التلاوة الأمريكية' },
    { id: 'canada1', name: 'إسماعيل لونكريك', country: 'كندا', specialty: 'الأسلوب الكندي' },
    { id: 'uk1', name: 'قاري زياد باتل', country: 'بريطانيا', specialty: 'التلاوة البريطانية' },
    { id: 'france1', name: 'رشيد أولاد', country: 'فرنسا', specialty: 'الأسلوب الفرنسي' },
    { id: 'germany1', name: 'عبد الرحيم غرين', country: 'ألمانيا', specialty: 'التلاوة الألمانية' },
    { id: 'australia1', name: 'محمد حبيب', country: 'أستراليا', specialty: 'الأسلوب الأسترالي' }
  ];

  const surahs = [
    'الفاتحة', 'البقرة', 'آل عمران', 'النساء', 'المائدة', 'الأنعام', 'الأعراف', 'الأنفال', 'التوبة', 'يونس',
    'هود', 'يوسف', 'الرعد', 'إبراهيم', 'الحجر', 'النحل', 'الإسراء', 'الكهف', 'مريم', 'طه',
    'الأنبياء', 'الحج', 'المؤمنون', 'النور', 'الفرقان', 'الشعراء', 'النمل', 'القصص', 'العنكبوت', 'الروم'
  ];

  const filteredReciters = reciters.filter(reciter => 
    reciter.name.includes(searchTerm) || 
    reciter.country.includes(searchTerm) ||
    reciter.specialty.includes(searchTerm)
  );

  const countryGroups = filteredReciters.reduce((groups, reciter) => {
    const country = reciter.country;
    if (!groups[country]) {
      groups[country] = [];
    }
    groups[country].push(reciter);
    return groups;
  }, {} as Record<string, typeof reciters>);

  return (
    <div className="space-y-6">
      {/* Header with Back Button */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 space-x-reverse text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors bg-white dark:bg-gray-800 px-4 py-2 rounded-xl shadow-md hover:shadow-lg"
        >
          <span>← العودة للرئيسية</span>
        </button>
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">القرآن الكريم</h1>
        </div>
        <div></div>
      </div>
      
      <div className="text-center">
        <div className="flex justify-center mb-4">
          <div className="bg-gradient-to-br from-green-600 to-emerald-700 p-4 rounded-full">
            <Book className="w-12 h-12 text-white" />
          </div>
        </div>
        <p className="text-gray-600 dark:text-gray-400">
          استمع لتلاوة القرآن الكريم بأصوات أشهر القراء
        </p>
      </div>

      {/* Search */}
      <div className="relative max-w-md mx-auto">
        <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
        <input
          type="text"
          placeholder="ابحث عن قارئ..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-4 pr-10 py-3 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
        />
      </div>

      {/* Reciters by Country */}
      <div className="space-y-8">
        {Object.entries(countryGroups).map(([country, countryReciters]) => (
          <div key={country}>
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4 flex items-center space-x-2 space-x-reverse">
              <Star className="w-5 h-5 text-green-600" />
              <span>قراء {country}</span>
              <span className="text-sm text-gray-500 dark:text-gray-400">({countryReciters.length})</span>
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {countryReciters.map((reciter) => (
                <div
                  key={reciter.id}
                  onClick={() => setSelectedReciter(reciter.id)}
                  className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 border border-gray-200 dark:border-gray-700 cursor-pointer group"
                >
                  <div className="flex items-center space-x-4 space-x-reverse">
                    <div className="bg-gradient-to-br from-green-500 to-emerald-600 p-3 rounded-full group-hover:scale-110 transition-transform duration-300">
                      <BookOpen className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1 text-right">
                      <h3 className="font-bold text-gray-900 dark:text-white group-hover:text-green-600 dark:group-hover:text-green-400 transition-colors">
                        {reciter.name}
                      </h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {reciter.specialty}
                      </p>
                      <div className="flex items-center justify-end space-x-1 space-x-reverse mt-2">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setFavorites(prev => 
                              prev.includes(reciter.id) 
                                ? prev.filter(id => id !== reciter.id)
                                : [...prev, reciter.id]
                            );
                          }}
                        >
                          <Heart className={`w-4 h-4 ${favorites.includes(reciter.id) ? 'text-red-500 fill-red-500' : 'text-gray-400'}`} />
                        </button>
                        <span className="text-xs text-gray-500 dark:text-gray-400">محبوب</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Surah Selection */}
      {selectedReciter && !isPlaying && (
        <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4">اختر السورة</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {surahs.map((surah, index) => (
              <button
                key={index}
                onClick={() => {
                  setSelectedSurah(surah);
                  setIsPlaying(true);
                }}
                className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 p-3 rounded-lg hover:bg-green-200 dark:hover:bg-green-800 transition-colors text-sm"
              >
                {index + 1}. {surah}
              </button>
            ))}
          </div>
        </div>
      )}
      {/* Audio Player (when reciter is selected) */}
      {selectedReciter && (
        <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 p-4 shadow-2xl z-30">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4 space-x-reverse">
                <div className="bg-gradient-to-br from-green-500 to-emerald-600 p-3 rounded-full">
                  <BookOpen className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="font-bold text-gray-900 dark:text-white">
                    {reciters.find(r => r.id === selectedReciter)?.name}
                  </h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {selectedSurah || 'سورة الفاتحة'}
                  </p>
                </div>
              </div>
              
              <div className="flex items-center space-x-4 space-x-reverse">
                <select
                  value={playbackSpeed}
                  onChange={(e) => setPlaybackSpeed(parseFloat(e.target.value))}
                  className="text-sm bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white rounded px-2 py-1"
                >
                  <option value={0.5}>0.5x</option>
                  <option value={0.75}>0.75x</option>
                  <option value={1}>1x</option>
                  <option value={1.25}>1.25x</option>
                  <option value={1.5}>1.5x</option>
                </select>
                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="bg-green-600 text-white p-3 rounded-full hover:bg-green-700 transition-colors"
                >
                  {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                </button>
                <button className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors">
                  <Volume2 className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setSelectedReciter(null)}
                  className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
                >
                  ✕
                </button>
              </div>
            </div>
            
            {/* Progress Bar */}
            <div className="mt-4">
              <div className="flex items-center justify-between text-sm text-gray-600 dark:text-gray-400 mb-1">
                <span>{Math.floor(currentTime / 60)}:{(currentTime % 60).toString().padStart(2, '0')}</span>
                <span>{Math.floor(duration / 60)}:{(duration % 60).toString().padStart(2, '0')}</span>
              </div>
              <div className="bg-gray-200 dark:bg-gray-700 rounded-full h-2 cursor-pointer">
                <div 
                  className="bg-green-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: duration > 0 ? `${(currentTime / duration) * 100}%` : '33%' }}
                ></div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default QuranSection;