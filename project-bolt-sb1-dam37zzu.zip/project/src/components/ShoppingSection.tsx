import React, { useState } from 'react';
import { 
  Package, 
  Armchair, 
  Home, 
  Wrench, 
  Zap, 
  Search, 
  Filter, 
  Star,
  ShoppingCart,
  Heart,
  Grid3X3,
  List
} from 'lucide-react';

interface ShoppingSectionProps {
  section: 'categories' | 'products';
  onAddToCart: (item: any) => void;
  onBack: () => void;
}

const ShoppingSection: React.FC<ShoppingSectionProps> = ({ section, onAddToCart, onBack }) => {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState<'name' | 'price' | 'rating'>('name');
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 10000]);
  const [showFilters, setShowFilters] = useState(false);

  const categories = [
    {
      id: 'sponges',
      title: 'الاسفنج',
      icon: Package,
      color: 'from-yellow-400 to-orange-500',
      subcategories: [
        'اسفنج طبيعي',
        'اسفنج صناعي',
        'اسفنج طبي',
        'اسفنج تنظيف',
        'اسفنج ديكور',
        'اسفنج عزل'
      ]
    },
    {
      id: 'furniture',
      title: 'الأثاث',
      icon: Armchair,
      color: 'from-blue-500 to-indigo-600',
      subcategories: [
        'غرف النوم',
        'غرف المعيشة',
        'غرف الطعام',
        'مكاتب وكراسي',
        'أثاث أطفال',
        'أثاث حدائق',
        'خزائن ودواليب',
        'طاولات متنوعة'
      ]
    },
    {
      id: 'upholstery',
      title: 'المفروشات',
      icon: Home,
      color: 'from-purple-500 to-pink-600',
      subcategories: [
        'سجاد وموكيت',
        'ستائر ومفارش',
        'وسائد ومخدات',
        'مفارش سرير',
        'مناشف حمام',
        'اكسسوارات ديكور',
        'لحف وبطانيات'
      ]
    },
    {
      id: 'home-tools',
      title: 'الأدوات المنزلية',
      icon: Wrench,
      color: 'from-green-500 to-teal-600',
      subcategories: [
        'أدوات مطبخ',
        'أدوات تنظيف',
        'أدوات حمام',
        'أدوات حديقة',
        'أدوات صيانة',
        'منظمات ومرتبات',
        'أدوات غسيل'
      ]
    },
    {
      id: 'electrical',
      title: 'الأدوات الكهربائية',
      icon: Zap,
      color: 'from-red-500 to-orange-600',
      subcategories: [
        'أجهزة مطبخ',
        'أجهزة تنظيف',
        'أجهزة تدفئة وتبريد',
        'أجهزة إضاءة',
        'أجهزة صوت ومرئي',
        'أجهزة أمان',
        'أجهزة شخصية',
        'أجهزة حديقة'
      ]
    }
  ];

  const sampleProducts = [
    {
      id: 1,
      name: 'اسفنج طبيعي فاخر',
      price: '45 ريال',
      category: 'sponges',
      image: 'https://images.pexels.com/photos/4239091/pexels-photo-4239091.jpeg',
      rating: 4.8,
      reviews: 124
    },
    {
      id: 2,
      name: 'أريكة فاخرة 3 مقاعد',
      price: '2,500 ريال',
      category: 'furniture',
      image: 'https://images.pexels.com/photos/586960/pexels-photo-586960.jpeg',
      rating: 4.9,
      reviews: 89
    },
    {
      id: 3,
      name: 'سجادة فارسية أصلية',
      price: '850 ريال',
      category: 'upholstery',
      image: 'https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg',
      rating: 4.7,
      reviews: 156
    },
    {
      id: 4,
      name: 'طقم سكاكين مطبخ احترافي',
      price: '180 ريال',
      category: 'home-tools',
      image: 'https://images.pexels.com/photos/2291367/pexels-photo-2291367.jpeg',
      rating: 4.6,
      reviews: 203
    },
    {
      id: 5,
      name: 'خلاط كهربائي متعدد الاستخدامات',
      price: '320 ريال',
      category: 'electrical',
      image: 'https://images.pexels.com/photos/4226769/pexels-photo-4226769.jpeg',
      rating: 4.8,
      reviews: 97
    }
  ];

  const filteredProducts = sampleProducts.filter(product => 
    product.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
    (!selectedCategory || product.category === selectedCategory) &&
    (parseFloat(product.price.replace(/[^\d.]/g, '')) >= priceRange[0] && 
     parseFloat(product.price.replace(/[^\d.]/g, '')) <= priceRange[1])
  ).sort((a, b) => {
    if (sortBy === 'name') return a.name.localeCompare(b.name);
    if (sortBy === 'price') return parseFloat(a.price.replace(/[^\d.]/g, '')) - parseFloat(b.price.replace(/[^\d.]/g, ''));
    if (sortBy === 'rating') return b.rating - a.rating;
    return 0;
  });

  if (section === 'categories') {
    return (
      <div className="space-y-6">
        {/* Header with Back Button */}
        <div className="flex items-center justify-between">
          <button
            onClick={onBack}
            className="flex items-center space-x-2 space-x-reverse text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors bg-white dark:bg-gray-800 px-4 py-2 rounded-xl shadow-md hover:shadow-lg"
          >
            <span>← العودة للرئيسية</span>
          </button>
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">مجموعات المنتجات</h1>
          </div>
          <div></div>
        </div>

        <div className="text-center">
          <p className="text-gray-600 dark:text-gray-400">
            اختر المجموعة المناسبة لك
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories.map((category) => (
            <div
              key={category.id}
              className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-200 dark:border-gray-700 overflow-hidden group cursor-pointer"
              onClick={() => {
                setSelectedCategory(category.id);
                // يمكن إضافة منطق للانتقال لصفحة المنتجات هنا
              }}
            >
              <div className={`bg-gradient-to-br ${category.color} p-6 text-white relative overflow-hidden`}>
                <div className="absolute inset-0 bg-black/10 group-hover:bg-black/20 transition-colors duration-300"></div>
                <div className="relative z-10 flex items-center justify-between">
                  <div>
                    <category.icon className="w-12 h-12 mb-4 group-hover:scale-110 transition-transform duration-300" />
                    <h3 className="text-2xl font-bold mb-2">{category.title}</h3>
                    <p className="text-white/90 text-sm">
                      {category.subcategories.length} أقسام فرعية
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="p-6">
                <h4 className="font-semibold text-gray-900 dark:text-white mb-3">الأقسام الفرعية:</h4>
                <div className="space-y-2">
                  {category.subcategories.slice(0, 4).map((sub, index) => (
                    <div key={index} className="flex items-center space-x-2 space-x-reverse text-sm text-gray-600 dark:text-gray-400">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      <span>{sub}</span>
                    </div>
                  ))}
                  {category.subcategories.length > 4 && (
                    <div className="text-sm text-blue-600 dark:text-blue-400 font-medium">
                      +{category.subcategories.length - 4} أقسام أخرى
                    </div>
                  )}
                </div>
              </div>
              
              {/* زر الدخول للمجموعة */}
              <div className="p-4">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    alert(`الدخول إلى مجموعة ${category.title}`);
                  }}
                  className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-2 rounded-xl font-semibold hover:shadow-lg transform hover:scale-105 transition-all duration-300"
                >
                  دخول المجموعة
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="space-y-4">
        {/* Back Button */}
        <div className="flex items-center justify-between">
          <button
            onClick={onBack}
            className="flex items-center space-x-2 space-x-reverse text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors bg-white dark:bg-gray-800 px-4 py-2 rounded-xl shadow-md hover:shadow-lg"
          >
            <span>← العودة للرئيسية</span>
          </button>
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">المنتجات</h1>
          </div>
          <div></div>
        </div>
        
        {/* Header Content */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <p className="text-gray-600 dark:text-gray-400">
            اكتشف مجموعتنا المتنوعة من المنتجات عالية الجودة
          </p>
        </div>
        
        <div className="flex items-center space-x-4 space-x-reverse">
          <div className="flex bg-gray-100 dark:bg-gray-700 rounded-lg p-1">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 rounded-md transition-colors ${
                viewMode === 'grid' 
                  ? 'bg-white dark:bg-gray-600 text-blue-600 dark:text-blue-400 shadow-sm' 
                  : 'text-gray-600 dark:text-gray-400'
              }`}
            >
              <Grid3X3 className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 rounded-md transition-colors ${
                viewMode === 'list' 
                  ? 'bg-white dark:bg-gray-600 text-blue-600 dark:text-blue-400 shadow-sm' 
                  : 'text-gray-600 dark:text-gray-400'
              }`}
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col lg:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder="ابحث عن المنتجات..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-4 pr-10 py-3 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
          />
        </div>
        
        <div className="flex items-center space-x-4 space-x-reverse">
          <select
            value={selectedCategory || ''}
            onChange={(e) => setSelectedCategory(e.target.value || null)}
            className="px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
          >
            <option value="">جميع الفئات</option>
            {categories.map((cat) => (
              <option key={cat.id} value={cat.id}>{cat.title}</option>
            ))}
          </select>
          
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
          >
            <option value="name">ترتيب بالاسم</option>
            <option value="price">ترتيب بالسعر</option>
            <option value="rating">ترتيب بالتقييم</option>
          </select>
          
            onClick={() => setShowFilters(!showFilters)}
          <button className="flex items-center space-x-2 space-x-reverse px-4 py-3 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-xl hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors">
            <Filter className="w-4 h-4" />
            <span>فلترة</span>
          </button>
        </div>
      </div>

      {/* Advanced Filters */}
      {showFilters && (
        <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 space-y-4">
          <h3 className="font-bold text-gray-900 dark:text-white">فلترة متقدمة</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                نطاق السعر: {priceRange[0]} - {priceRange[1]} ريال
              </label>
              <div className="flex items-center space-x-4 space-x-reverse">
                <input
                  type="range"
                  min="0"
                  max="10000"
                  value={priceRange[0]}
                  onChange={(e) => setPriceRange([parseInt(e.target.value), priceRange[1]])}
                  className="flex-1"
                />
                <input
                  type="range"
                  min="0"
                  max="10000"
                  value={priceRange[1]}
                  onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
                  className="flex-1"
                />
              </div>
            </div>
            <div className="flex items-end">
              <button
                onClick={() => {
                  setPriceRange([0, 10000]);
                  setSelectedCategory(null);
                  setSearchTerm('');
                }}
                className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition-colors"
              >
                إعادة تعيين الفلاتر
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Products Grid/List */}
      <div className={`${
        viewMode === 'grid' 
          ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6' 
          : 'space-y-4'
      }`}>
        {filteredProducts.map((product) => (
          <div
            key={product.id}
            className={`bg-white dark:bg-gray-800 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-200 dark:border-gray-700 overflow-hidden group ${
              viewMode === 'list' ? 'flex' : ''
            }`}
          >
            <div className={`${viewMode === 'list' ? 'w-48 flex-shrink-0' : 'aspect-square'} relative overflow-hidden`}>
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              />
              <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm rounded-full p-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <Heart className="w-4 h-4 text-gray-600 hover:text-red-500 transition-colors" />
              </div>
            </div>
            
            <div className="p-6 flex-1">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-lg font-bold text-gray-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                  {product.name}
                </h3>
                <div className="flex items-center space-x-1 space-x-reverse">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  <span className="text-sm text-gray-600 dark:text-gray-400">{product.rating}</span>
                </div>
              </div>
              
              <p className="text-gray-600 dark:text-gray-400 text-sm mb-3">
                {product.reviews} تقييم
              </p>
              
              <div className="flex items-center justify-between">
                <span className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                  {product.price}
                </span>
                <button
                  onClick={() => onAddToCart(product)}
                  className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-4 py-2 rounded-xl hover:shadow-lg transform hover:scale-105 transition-all duration-300 flex items-center space-x-2 space-x-reverse"
                >
                  <ShoppingCart className="w-4 h-4" />
                  <span>أضف للسلة</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredProducts.length === 0 && (
        <div className="text-center py-12">
          <Package className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
            لا توجد منتجات
          </h3>
          <p className="text-gray-600 dark:text-gray-400">
            جرب تغيير معايير البحث أو الفلترة
          </p>
        </div>
      )}
    </div>
  );
};

export default ShoppingSection;