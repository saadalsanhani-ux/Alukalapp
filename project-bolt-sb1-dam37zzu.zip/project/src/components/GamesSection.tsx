import React, { useState } from 'react';
import { 
  Play, 
  Users, 
  Bluetooth, 
  Wifi, 
  Trophy, 
  Star,
  Settings,
  Volume2,
  Pause,
  RotateCcw,
  Crown,
  Gamepad2
} from 'lucide-react';

interface GamesSectionProps {
  onBack: () => void;
}

const GamesSection: React.FC<GamesSectionProps> = ({ onBack }) => {
  const [selectedGame, setSelectedGame] = useState<string | null>(null);
  const [gameMode, setGameMode] = useState<'online' | 'bluetooth'>('online');
  const [viewStyle, setViewStyle] = useState<'classic' | 'modern' | '3d'>('modern');
  const [gameStarted, setGameStarted] = useState(false);
  const [gameScore, setGameScore] = useState({ player1: 0, player2: 0 });
  const [currentPlayer, setCurrentPlayer] = useState(1);
  const [gameTimer, setGameTimer] = useState(0);
  const [selectedQuizGame, setSelectedQuizGame] = useState<string | null>(null);

  const games = [
    {
      id: 'domino',
      title: 'الدومينو',
      description: 'لعبة الدومينو التقليدية مع أصدقائك',
      image: 'https://images.pexels.com/photos/5428834/pexels-photo-5428834.jpeg',
      players: '2-4 لاعبين',
      difficulty: 'سهل',
      color: 'from-emerald-500 to-teal-600'
    },
    {
      id: 'chess',
      title: 'الشطرنج',
      description: 'لعبة الشطرنج الاستراتيجية الكلاسيكية',
      image: 'https://images.pexels.com/photos/260024/pexels-photo-260024.jpeg',
      players: '2 لاعبين',
      difficulty: 'متوسط',
      color: 'from-gray-600 to-gray-800'
    },
    {
      id: 'billiards',
      title: 'البلياردو',
      description: 'لعبة البلياردو بفيزياء واقعية',
      image: 'https://images.pexels.com/photos/442428/pexels-photo-442428.jpeg',
      players: '2 لاعبين',
      difficulty: 'متوسط',
      color: 'from-green-600 to-emerald-700'
    },
    {
      id: 'quiz',
      title: 'المسابقات والألغاز',
      description: 'مسابقات ثقافية وألعاب ذهنية ممتعة',
      image: 'https://images.pexels.com/photos/3825572/pexels-photo-3825572.jpeg',
      players: '1+ لاعبين',
      difficulty: 'متنوع',
      color: 'from-purple-600 to-indigo-700'
    }
  ];

  const quizGames = [
    { id: 'cultural', title: 'المسابقة الثقافية', icon: '🧠' },
    { id: 'four-pics', title: 'أربع صور', icon: '🖼️' },
    { id: 'memory', title: 'ألعاب الذاكرة', icon: '🎯' },
    { id: 'math', title: 'الألغاز الحسابية', icon: '🔢' },
    { id: 'word', title: 'ألعاب الكلمات', icon: '📝' },
    { id: 'geography', title: 'الجغرافيا', icon: '🌍' }
  ];

  if (selectedGame) {
    return (
      <div className="space-y-6">
        {/* Game Header */}
        <div className="flex items-center justify-between">
          <button
            onClick={() => setSelectedGame(null)}
            className="flex items-center space-x-2 space-x-reverse text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors bg-white dark:bg-gray-800 px-4 py-2 rounded-xl shadow-md hover:shadow-lg"
          >
            <span>← العودة للألعاب</span>
          </button>
          
          <div className="flex items-center space-x-4 space-x-reverse">
            <select
              value={viewStyle}
              onChange={(e) => setViewStyle(e.target.value as any)}
              className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            >
              <option value="classic">كلاسيكي</option>
              <option value="modern">عصري</option>
              <option value="3d">ثلاثي الأبعاد</option>
            </select>
            
            <div className="flex bg-gray-100 dark:bg-gray-700 rounded-lg p-1">
              <button
                onClick={() => setGameMode('online')}
                className={`px-3 py-1 rounded-md text-sm transition-colors ${
                  gameMode === 'online' 
                    ? 'bg-white dark:bg-gray-600 text-blue-600 dark:text-blue-400 shadow-sm' 
                    : 'text-gray-600 dark:text-gray-400'
                }`}
              >
                <Wifi className="w-4 h-4 inline ml-1" />
                أونلاين
              </button>
              <button
                onClick={() => setGameMode('bluetooth')}
                className={`px-3 py-1 rounded-md text-sm transition-colors ${
                  gameMode === 'bluetooth' 
                    ? 'bg-white dark:bg-gray-600 text-blue-600 dark:text-blue-400 shadow-sm' 
                    : 'text-gray-600 dark:text-gray-400'
                }`}
              >
                <Bluetooth className="w-4 h-4 inline ml-1" />
                بلوتوث
              </button>
            </div>
          </div>
        </div>

        {/* Game Interface */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl border border-gray-200 dark:border-gray-700 overflow-hidden">
          {selectedGame === 'quiz' ? (
            <div className="p-8">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6 text-center">
                اختر نوع المسابقة
              </h2>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {quizGames.map((quiz) => (
                  <button
                    key={quiz.id}
                    onClick={() => {
                      setSelectedQuizGame(quiz.id);
                      setGameStarted(true);
                    }}
                    className="bg-gradient-to-br from-purple-500 to-indigo-600 text-white p-6 rounded-xl hover:shadow-lg transform hover:scale-105 transition-all duration-300"
                  >
                    <div className="text-4xl mb-3">{quiz.icon}</div>
                    <h3 className="font-bold">{quiz.title}</h3>
                  </button>
                ))}
              </div>
              
              {/* Quiz Game Interface */}
              {selectedQuizGame && gameStarted && (
                <div className="mt-8 bg-gradient-to-br from-purple-100 to-indigo-100 dark:from-purple-900 dark:to-indigo-900 p-6 rounded-xl">
                  <div className="text-center">
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">
                      {quizGames.find(q => q.id === selectedQuizGame)?.title}
                    </h3>
                    <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg">
                      <p className="text-lg text-gray-900 dark:text-white mb-4">
                        ما هي عاصمة المملكة العربية السعودية؟
                      </p>
                      <div className="grid grid-cols-2 gap-3">
                        {['الرياض', 'جدة', 'الدمام', 'مكة المكرمة'].map((option, index) => (
                          <button
                            key={index}
                            onClick={() => {
                              if (option === 'الرياض') {
                                setGameScore(prev => ({ ...prev, player1: prev.player1 + 1 }));
                              }
                            }}
                            className="bg-blue-500 text-white p-3 rounded-lg hover:bg-blue-600 transition-colors"
                          >
                            {option}
                          </button>
                        ))}
                      </div>
                      <div className="mt-4 text-center">
                        <span className="text-sm text-gray-600 dark:text-gray-400">
                          النقاط: {gameScore.player1}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="aspect-video bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-700 dark:to-gray-800 flex items-center justify-center relative">
            {/* Game Interface Based on Selected Game */}
            {selectedGame === 'domino' && (
              <div className="w-full h-full bg-green-800 rounded-lg relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-green-700 to-green-900"></div>
                <div className="relative z-10 p-8 text-center text-white">
                  <h3 className="text-2xl font-bold mb-4">لعبة الدومينو</h3>
                  <div className="grid grid-cols-7 gap-2 mb-6">
                    {Array.from({length: 28}).map((_, i) => (
                      <div key={i} className="bg-white rounded-md h-12 w-8 flex items-center justify-center text-black text-xs font-bold">
                        {Math.floor(i/4)}|{i%4}
                      </div>
                    ))}
                  </div>
                  <p className="mb-4">{gameMode === 'online' ? 'متصل أونلاين' : 'وضع البلوتوث'}</p>
                  <button 
                    onClick={() => setGameStarted(true)}
                    className="bg-yellow-500 text-black px-6 py-2 rounded-lg font-bold hover:bg-yellow-400 transition-colors">
                    ابدأ اللعب
                  </button>
                  {gameStarted && (
                    <div className="mt-4 text-center">
                      <p className="text-sm">اللعبة بدأت! النقاط: {gameScore.player1} - {gameScore.player2}</p>
                      <p className="text-xs">دور اللاعب {currentPlayer}</p>
                    </div>
                  )}
                </div>
              </div>
            )}
            
            {selectedGame === 'chess' && (
              <div className="w-full h-full bg-amber-100 dark:bg-amber-900 rounded-lg relative overflow-hidden">
                <div className="absolute inset-0">
                  <div className="grid grid-cols-8 grid-rows-8 h-full w-full">
                    {Array.from({length: 64}).map((_, i) => (
                      <div key={i} className={`${(Math.floor(i/8) + i) % 2 === 0 ? 'bg-amber-200 dark:bg-amber-800' : 'bg-amber-800 dark:bg-amber-200'} flex items-center justify-center text-2xl`}>
                        {i < 16 && '♟'}
                        {i >= 48 && '♙'}
                      </div>
                    ))}
                  </div>
                </div>
                <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-black/80 text-white px-4 py-2 rounded-lg">
                  <p className="text-sm">{gameMode === 'online' ? 'لعب أونلاين' : 'لعب بلوتوث'}</p>
                </div>
                {gameStarted && (
                  <div className="absolute top-4 left-4 bg-black/80 text-white px-3 py-1 rounded-lg text-sm">
                    النقاط: أبيض {gameScore.player1} - أسود {gameScore.player2}
                  </div>
                )}
              </div>
            )}
            
            {selectedGame === 'billiards' && (
              <div className="w-full h-full bg-green-600 rounded-lg relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-green-500 to-green-700"></div>
                <div className="relative z-10 flex items-center justify-center h-full">
                  <div className="relative">
                    {/* Pool balls */}
                    <div className="grid grid-cols-5 gap-2">
                      {Array.from({length: 15}).map((_, i) => (
                        <div key={i} className={`w-8 h-8 rounded-full ${i === 0 ? 'bg-white' : i <= 7 ? 'bg-red-500' : 'bg-yellow-500'} border-2 border-black flex items-center justify-center text-xs font-bold`}>
                          {i + 1}
                        </div>
                      ))}
                    </div>
                    <div className="mt-4 text-center text-white">
                      <p className="text-sm">{gameMode === 'online' ? 'طاولة أونلاين' : 'طاولة بلوتوث'}</p>
                      {gameStarted && (
                        <p className="text-xs mt-2">النقاط: {gameScore.player1} - {gameScore.player2}</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            {!['domino', 'chess', 'billiards'].includes(selectedGame) && (
              <div className="text-center">
                <div className="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-2xl border border-gray-200 dark:border-gray-700 max-w-md">
                  <Gamepad2 className="w-16 h-16 text-blue-600 dark:text-blue-400 mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                    جاري تحضير اللعبة
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400 mb-6">
                    {gameMode === 'online' ? 'البحث عن لاعبين...' : 'البحث عن أجهزة بلوتوث...'}
                  </p>
                  <button className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-3 rounded-xl hover:shadow-lg transform hover:scale-105 transition-all duration-300">
                    onClick={() => setGameStarted(true)}
                    ابدأ اللعب
                  </button>
                  {gameStarted && (
                    <div className="mt-4 text-center text-gray-900 dark:text-white">
                      <p className="text-sm">جاري البحث عن لاعبين...</p>
                      <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600 mx-auto mt-2"></div>
                    </div>
                  )}
                </div>
              </div>
            )}
              
              {/* Game Controls */}
              <div className="absolute bottom-4 left-4 flex items-center space-x-3 space-x-reverse">
                <button className="bg-white dark:bg-gray-800 p-3 rounded-full shadow-lg hover:shadow-xl transition-all duration-300">
                  onClick={() => {
                    // Game settings logic
                  }}
                  <Settings className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                </button>
                <button className="bg-white dark:bg-gray-800 p-3 rounded-full shadow-lg hover:shadow-xl transition-all duration-300">
                  onClick={() => {
                    // Volume control logic
                  }}
                  <Volume2 className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                </button>
                <button className="bg-white dark:bg-gray-800 p-3 rounded-full shadow-lg hover:shadow-xl transition-all duration-300">
                  onClick={() => {
                    setGameStarted(false);
                    setGameScore({ player1: 0, player2: 0 });
                    setCurrentPlayer(1);
                  }}
                  <RotateCcw className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header with Back Button */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 space-x-reverse text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors bg-white dark:bg-gray-800 px-4 py-2 rounded-xl shadow-md hover:shadow-lg"
        >
          <span>← العودة للرئيسية</span>
        </button>
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">مركز الألعاب</h1>
        </div>
        <div></div>
      </div>
      
      <div className="text-center">
        <p className="text-gray-600 dark:text-gray-400">
          استمتع بمجموعة متنوعة من الألعاب التفاعلية
        </p>
      </div>

      {/* Games Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {games.map((game) => (
          <div
            key={game.id}
            className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-200 dark:border-gray-700 overflow-hidden group cursor-pointer"
            onClick={() => setSelectedGame(game.id)}
          >
            <div className="relative h-48 overflow-hidden">
              <img
                src={game.image}
                alt={game.title}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              />
              <div className={`absolute inset-0 bg-gradient-to-t ${game.color} opacity-80 group-hover:opacity-70 transition-opacity duration-300`}></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <button className="bg-white/20 backdrop-blur-sm border border-white/30 text-white p-4 rounded-full hover:bg-white/30 transition-all duration-300 transform group-hover:scale-110">
                  <Play className="w-8 h-8" />
                </button>
              </div>
              <div className="absolute top-4 right-4">
                <Crown className="w-6 h-6 text-yellow-300" />
              </div>
            </div>
            
            <div className="p-6">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                {game.title}
              </h3>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                {game.description}
              </p>
              
              {/* زر دخول اللعبة */}
              <button
                onClick={() => setSelectedGame(game.id)}
                className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-3 rounded-xl font-semibold hover:shadow-lg transform hover:scale-105 transition-all duration-300 mb-4"
              >
                دخول اللعبة
              </button>
              
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center space-x-4 space-x-reverse">
                  <div className="flex items-center space-x-1 space-x-reverse">
                    <Users className="w-4 h-4 text-blue-500" />
                    <span className="text-gray-600 dark:text-gray-400">{game.players}</span>
                  </div>
                  <div className="flex items-center space-x-1 space-x-reverse">
                    <Trophy className="w-4 h-4 text-yellow-500" />
                    <span className="text-gray-600 dark:text-gray-400">{game.difficulty}</span>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2 space-x-reverse">
                  <Wifi className="w-4 h-4 text-green-500" />
                  <Bluetooth className="w-4 h-4 text-blue-500" />
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Game Modes Info */}
      <div className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-gray-800 dark:to-gray-900 p-6 rounded-2xl border border-blue-200 dark:border-gray-700">
        <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4 flex items-center space-x-2 space-x-reverse">
          <Gamepad2 className="w-5 h-5 text-blue-600" />
          <span>أوضاع اللعب المتاحة</span>
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="flex items-center space-x-3 space-x-reverse p-4 bg-white dark:bg-gray-700 rounded-xl">
            <Wifi className="w-6 h-6 text-green-500" />
            <div>
              <h4 className="font-semibold text-gray-900 dark:text-white">اللعب أونلاين</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">العب مع أصدقائك في أي مكان</p>
            </div>
          </div>
          <div className="flex items-center space-x-3 space-x-reverse p-4 bg-white dark:bg-gray-700 rounded-xl">
            <Bluetooth className="w-6 h-6 text-blue-500" />
            <div>
              <h4 className="font-semibold text-gray-900 dark:text-white">اللعب بالبلوتوث</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">العب مع الأصدقاء المجاورين</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GamesSection;