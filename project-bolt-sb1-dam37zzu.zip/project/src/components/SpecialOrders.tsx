import React, { useState } from 'react';
import { 
  Crown, 
  Star, 
  Package, 
  Clock, 
  CheckCircle, 
  MessageSquare,
  Upload,
  Camera,
  FileText,
  Palette,
  Sparkles,
  Award,
  Zap,
  Shield
} from 'lucide-react';

interface SpecialOrdersProps {
  onBack: () => void;
}

const SpecialOrders: React.FC<SpecialOrdersProps> = ({ onBack }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('custom');
  const [orderForm, setOrderForm] = useState({
    title: '',
    description: '',
    budget: '',
    deadline: '',
    category: 'custom',
    priority: 'normal'
  });

  const orderCategories = [
    {
      id: 'custom',
      title: 'طلبات مخصصة',
      description: 'منتجات مصممة خصيصاً لك',
      icon: Crown,
      color: 'from-yellow-500 to-orange-600',
      features: ['تصميم حسب الطلب', 'جودة عالية', 'ضمان شامل']
    },
    {
      id: 'premium',
      title: 'منتجات فاخرة',
      description: 'أفضل المنتجات الفاخرة والحصرية',
      icon: Star,
      color: 'from-purple-500 to-indigo-600',
      features: ['منتجات حصرية', 'علامات تجارية عالمية', 'خدمة VIP']
    },
    {
      id: 'bulk',
      title: 'طلبات بالجملة',
      description: 'كميات كبيرة بأسعار مميزة',
      icon: Package,
      color: 'from-green-500 to-teal-600',
      features: ['أسعار الجملة', 'كميات كبيرة', 'شحن مجاني']
    },
    {
      id: 'urgent',
      title: 'طلبات عاجلة',
      description: 'توصيل سريع في نفس اليوم',
      icon: Zap,
      color: 'from-red-500 to-pink-600',
      features: ['توصيل سريع', 'أولوية قصوى', 'متابعة مباشرة']
    }
  ];

  const specialServices = [
    {
      title: 'التصميم الشخصي',
      description: 'نصمم منتجك حسب مواصفاتك الدقيقة',
      icon: Palette,
      price: 'يبدأ من 500 ريال'
    },
    {
      title: 'الاستشارة المتخصصة',
      description: 'خبراء متخصصون لمساعدتك في اختيار الأفضل',
      icon: MessageSquare,
      price: 'مجاناً مع الطلب'
    },
    {
      title: 'ضمان الجودة المطلقة',
      description: 'ضمان استرداد كامل إذا لم تكن راضياً',
      icon: Shield,
      price: 'مضمون 100%'
    },
    {
      title: 'التوصيل الفوري',
      description: 'توصيل في نفس اليوم للطلبات العاجلة',
      icon: Clock,
      price: 'خلال ساعات'
    }
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Special order submitted:', orderForm);
    // Handle form submission
  };

  return (
    <div className="space-y-8">
      {/* Header with Back Button */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 space-x-reverse text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors bg-white dark:bg-gray-800 px-4 py-2 rounded-xl shadow-md hover:shadow-lg"
        >
          <span>← العودة للرئيسية</span>
        </button>
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">الطلبات الخاصة</h1>
        </div>
        <div></div>
      </div>
      
      {/* Header */}
      <div className="text-center">
        <div className="flex justify-center mb-6">
          <div className="bg-gradient-to-br from-yellow-500 to-orange-600 p-6 rounded-2xl shadow-2xl">
            <Crown className="w-16 h-16 text-white" />
          </div>
        </div>
        <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
          خدمة VIP مخصصة لطلباتك الخاصة والمميزة مع ضمان أعلى مستويات الجودة والخدمة
        </p>
      </div>

      {/* Order Categories */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {orderCategories.map((category) => (
          <div
            key={category.id}
            onClick={() => setSelectedCategory(category.id)}
            className={`bg-white dark:bg-gray-800 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border-2 cursor-pointer ${
              selectedCategory === category.id 
                ? 'border-yellow-500 ring-2 ring-yellow-200 dark:ring-yellow-800' 
                : 'border-gray-200 dark:border-gray-700'
            }`}
          >
            <div className={`bg-gradient-to-br ${category.color} p-6 text-white rounded-t-2xl`}>
              <category.icon className="w-12 h-12 mb-4" />
              <h3 className="text-xl font-bold mb-2">{category.title}</h3>
              <p className="text-white/90 text-sm">{category.description}</p>
            </div>
            
            <div className="p-6">
              <div className="space-y-2">
                {category.features.map((feature, index) => (
                  <div key={index} className="flex items-center space-x-2 space-x-reverse">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    <span className="text-sm text-gray-600 dark:text-gray-400">{feature}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Special Services */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6 text-center">
          خدمات مميزة إضافية
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {specialServices.map((service, index) => (
            <div
              key={index}
              className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 hover:shadow-xl transition-all duration-300"
            >
              <div className="bg-gradient-to-br from-blue-100 to-purple-100 dark:from-blue-900 dark:to-purple-900 p-4 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <service.icon className="w-8 h-8 text-blue-600 dark:text-blue-400" />
              </div>
              <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2 text-center">
                {service.title}
              </h3>
              <p className="text-gray-600 dark:text-gray-400 text-sm mb-4 text-center">
                {service.description}
              </p>
              <div className="text-center">
                <span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-3 py-1 rounded-full text-sm font-semibold">
                  {service.price}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Order Form */}
      <div className="max-w-4xl mx-auto">
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl border border-gray-200 dark:border-gray-700 p-8">
          <div className="flex items-center space-x-3 space-x-reverse mb-6">
            <Sparkles className="w-8 h-8 text-yellow-600 dark:text-yellow-400" />
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
              اطلب خدمتك المميزة
            </h2>
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  عنوان الطلب
                </label>
                <input
                  type="text"
                  value={orderForm.title}
                  onChange={(e) => setOrderForm({...orderForm, title: e.target.value})}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-yellow-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  placeholder="اكتب عنوان طلبك المميز"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  فئة الطلب
                </label>
                <select
                  value={orderForm.category}
                  onChange={(e) => setOrderForm({...orderForm, category: e.target.value})}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-yellow-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                >
                  {orderCategories.map((cat) => (
                    <option key={cat.id} value={cat.id}>{cat.title}</option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                وصف تفصيلي للطلب
              </label>
              <textarea
                value={orderForm.description}
                onChange={(e) => setOrderForm({...orderForm, description: e.target.value})}
                rows={6}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-yellow-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white resize-none"
                placeholder="اشرح طلبك بالتفصيل، المواصفات المطلوبة، والمتطلبات الخاصة..."
                required
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  الميزانية المتوقعة
                </label>
                <input
                  type="text"
                  value={orderForm.budget}
                  onChange={(e) => setOrderForm({...orderForm, budget: e.target.value})}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-yellow-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  placeholder="مثال: 1000-5000 ريال"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  الموعد المطلوب
                </label>
                <input
                  type="date"
                  value={orderForm.deadline}
                  onChange={(e) => setOrderForm({...orderForm, deadline: e.target.value})}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-yellow-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  أولوية الطلب
                </label>
                <select
                  value={orderForm.priority}
                  onChange={(e) => setOrderForm({...orderForm, priority: e.target.value})}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-yellow-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                >
                  <option value="normal">عادي</option>
                  <option value="high">عالي</option>
                  <option value="urgent">عاجل</option>
                </select>
              </div>
            </div>

            {/* File Upload */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                إرفاق ملفات أو صور (اختياري)
              </label>
              <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-xl p-8 text-center hover:border-yellow-500 transition-colors">
                <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 dark:text-gray-400 mb-2">
                  اسحب الملفات هنا أو اضغط للاختيار
                </p>
                <p className="text-sm text-gray-500 dark:text-gray-500">
                  يدعم: PDF, DOC, JPG, PNG (حد أقصى 10MB)
                </p>
                <button
                  type="button"
                  className="mt-4 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 px-4 py-2 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
                >
                  اختيار ملفات
                </button>
              </div>
            </div>

            <div className="flex justify-center">
              <button
                type="submit"
                className="bg-gradient-to-r from-yellow-500 to-orange-600 text-white px-12 py-4 rounded-xl font-bold text-lg hover:shadow-lg transform hover:scale-105 transition-all duration-300 flex items-center space-x-3 space-x-reverse"
              >
                <Crown className="w-6 h-6" />
                <span>إرسال الطلب المميز</span>
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* VIP Benefits */}
      <div className="bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-900/20 dark:to-orange-900/20 p-8 rounded-2xl border border-yellow-200 dark:border-yellow-700">
        <div className="text-center">
          <Award className="w-12 h-12 text-yellow-600 dark:text-yellow-400 mx-auto mb-4" />
          <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
            مميزات خدمة VIP
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
            <div className="text-center">
              <div className="bg-yellow-100 dark:bg-yellow-900 p-3 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
                <Star className="w-6 h-6 text-yellow-600 dark:text-yellow-400" />
              </div>
              <h4 className="font-bold text-gray-900 dark:text-white mb-2">أولوية قصوى</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">طلبك يحصل على الأولوية في التنفيذ</p>
            </div>
            <div className="text-center">
              <div className="bg-yellow-100 dark:bg-yellow-900 p-3 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
                <MessageSquare className="w-6 h-6 text-yellow-600 dark:text-yellow-400" />
              </div>
              <h4 className="font-bold text-gray-900 dark:text-white mb-2">مدير حساب مخصص</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">مدير حساب شخصي لمتابعة طلبك</p>
            </div>
            <div className="text-center">
              <div className="bg-yellow-100 dark:bg-yellow-900 p-3 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
                <Shield className="w-6 h-6 text-yellow-600 dark:text-yellow-400" />
              </div>
              <h4 className="font-bold text-gray-900 dark:text-white mb-2">ضمان مطلق</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">ضمان الجودة والرضا الكامل</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SpecialOrders;