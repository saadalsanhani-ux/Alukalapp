import React, { useState } from 'react';
import { 
  Brain, 
  MessageSquare, 
  Image, 
  FileText, 
  Code, 
  Mic, 
  Video, 
  BarChart3,
  Sparkles,
  Crown,
  ExternalLink,
  Star,
  Zap
} from 'lucide-react';

interface AILibraryProps {
  onBack: () => void;
}

const AILibrary: React.FC<AILibraryProps> = ({ onBack }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const aiTools = [
    {
      id: 'chatgpt',
      name: 'ChatGPT Plus',
      description: 'المساعد الذكي الأكثر تطورًا للمحادثة والإجابة على الأسئلة',
      category: 'chat',
      icon: MessageSquare,
      color: 'from-green-500 to-emerald-600',
      premium: true,
      rating: 4.9,
      features: ['محادثة ذكية', 'كتابة إبداعية', 'حل المشاكل', 'ترجمة']
    },
    {
      id: 'midjourney',
      name: 'Midjourney',
      description: 'أفضل أداة لتوليد الصور بالذكاء الاصطناعي',
      category: 'image',
      icon: Image,
      color: 'from-purple-500 to-indigo-600',
      premium: true,
      rating: 4.8,
      features: ['صور فنية', 'دقة عالية', 'أنماط متنوعة', 'سهولة الاستخدام']
    },
    {
      id: 'claude',
      name: 'Claude 3.5 Sonnet',
      description: 'مساعد ذكي متقدم للتحليل والكتابة والبرمجة',
      category: 'chat',
      icon: Brain,
      color: 'from-blue-500 to-cyan-600',
      premium: true,
      rating: 4.9,
      features: ['تحليل عميق', 'برمجة متقدمة', 'كتابة أكاديمية', 'تفكير منطقي']
    },
    {
      id: 'copilot',
      name: 'GitHub Copilot',
      description: 'مساعد البرمجة الذكي لكتابة الكود',
      category: 'code',
      icon: Code,
      color: 'from-gray-600 to-gray-800',
      premium: true,
      rating: 4.7,
      features: ['إكمال الكود', 'اقتراحات ذكية', 'عدة لغات', 'تحسين الأداء']
    },
    {
      id: 'eleven-labs',
      name: 'ElevenLabs',
      description: 'تحويل النص إلى صوت بجودة طبيعية',
      category: 'audio',
      icon: Mic,
      color: 'from-orange-500 to-red-600',
      premium: true,
      rating: 4.8,
      features: ['أصوات طبيعية', 'دعم العربية', 'تخصيص الصوت', 'جودة عالية']
    },
    {
      id: 'runway',
      name: 'Runway ML',
      description: 'إنتاج ومونتاج الفيديو بالذكاء الاصطناعي',
      category: 'video',
      icon: Video,
      color: 'from-pink-500 to-rose-600',
      premium: true,
      rating: 4.6,
      features: ['توليد فيديو', 'مونتاج ذكي', 'تأثيرات خاصة', 'جودة احترافية']
    },
    {
      id: 'grammarly',
      name: 'Grammarly',
      description: 'تصحيح وتحسين الكتابة باللغة الإنجليزية',
      category: 'text',
      icon: FileText,
      color: 'from-teal-500 to-green-600',
      premium: false,
      rating: 4.5,
      features: ['تصحيح نحوي', 'تحسين الأسلوب', 'كشف الانتحال', 'اقتراحات ذكية']
    },
    {
      id: 'tableau',
      name: 'Tableau',
      description: 'تحليل البيانات وإنشاء المخططات الذكية',
      category: 'analytics',
      icon: BarChart3,
      color: 'from-indigo-500 to-blue-600',
      premium: true,
      rating: 4.7,
      features: ['تحليل البيانات', 'مخططات تفاعلية', 'تقارير ذكية', 'ربط مصادر متعددة']
    }
  ];

  const categories = [
    { id: 'all', title: 'جميع الأدوات', icon: Sparkles },
    { id: 'chat', title: 'المحادثة الذكية', icon: MessageSquare },
    { id: 'image', title: 'معالجة الصور', icon: Image },
    { id: 'text', title: 'معالجة النصوص', icon: FileText },
    { id: 'code', title: 'البرمجة', icon: Code },
    { id: 'audio', title: 'الصوت', icon: Mic },
    { id: 'video', title: 'الفيديو', icon: Video },
    { id: 'analytics', title: 'التحليلات', icon: BarChart3 }
  ];

  const filteredTools = selectedCategory === 'all' 
    ? aiTools 
    : aiTools.filter(tool => tool.category === selectedCategory);

  return (
    <div className="space-y-8">
      {/* Header with Back Button */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 space-x-reverse text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors bg-white dark:bg-gray-800 px-4 py-2 rounded-xl shadow-md hover:shadow-lg"
        >
          <span>← العودة للرئيسية</span>
        </button>
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">مكتبة الذكاء الاصطناعي</h1>
        </div>
        <div></div>
      </div>
      
      <div className="text-center">
        <p className="text-gray-600 dark:text-gray-400">
          أفضل أدوات الذكاء الاصطناعي المتاحة للاشتراك والاستخدام
        </p>
      </div>

      {/* Categories Filter */}
      <div className="flex flex-wrap gap-3 justify-center">
        {categories.map((category) => (
          <button
            key={category.id}
            onClick={() => setSelectedCategory(category.id)}
            className={`flex items-center space-x-2 space-x-reverse px-4 py-2 rounded-xl transition-all duration-300 ${
              selectedCategory === category.id
                ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg'
                : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
            }`}
          >
            <category.icon className="w-4 h-4" />
            <span className="text-sm font-medium">{category.title}</span>
          </button>
        ))}
      </div>

      {/* AI Tools Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTools.map((tool) => (
          <div
            key={tool.id}
            className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-200 dark:border-gray-700 overflow-hidden group"
          >
            <div className={`bg-gradient-to-br ${tool.color} p-6 text-white relative`}>
              {tool.premium && (
                <div className="absolute top-3 left-3">
                  <Crown className="w-5 h-5 text-yellow-300" />
                </div>
              )}
              <tool.icon className="w-12 h-12 mb-4 group-hover:scale-110 transition-transform duration-300" />
              <h3 className="text-xl font-bold mb-2">{tool.name}</h3>
              <div className="flex items-center space-x-2 space-x-reverse">
                <Star className="w-4 h-4 fill-yellow-300 text-yellow-300" />
                <span className="text-sm">{tool.rating}</span>
              </div>
            </div>
            
            <div className="p-6">
              <p className="text-gray-600 dark:text-gray-400 mb-4 leading-relaxed">
                {tool.description}
              </p>
              
              <div className="space-y-3 mb-4">
                <h4 className="font-semibold text-gray-900 dark:text-white text-sm">المميزات:</h4>
                <div className="flex flex-wrap gap-1">
                  {tool.features.map((feature, index) => (
                    <span
                      key={index}
                      className="bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 px-2 py-1 rounded-full text-xs"
                    >
                      {feature}
                    </span>
                  ))}
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <span className={`text-sm font-medium ${
                  tool.premium ? 'text-yellow-600 dark:text-yellow-400' : 'text-green-600 dark:text-green-400'
                }`}>
                  {tool.premium ? 'مدفوع' : 'مجاني'}
                </span>
                  onClick={() => {
                    // Simulate subscription process
                    alert(`سيتم توجيهك لصفحة الاشتراك في ${tool.name}`);
                  }}
                <button className="flex items-center space-x-2 space-x-reverse bg-gradient-to-r from-blue-600 to-purple-600 text-white px-4 py-2 rounded-xl hover:shadow-lg transform hover:scale-105 transition-all duration-300">
                  <ExternalLink className="w-4 h-4" />
                  <span>اشتراك</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Premium Notice */}
      <div className="bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-900/20 dark:to-orange-900/20 p-6 rounded-2xl border border-yellow-200 dark:border-yellow-700">
        <div className="flex items-center space-x-3 space-x-reverse mb-4">
          <Crown className="w-6 h-6 text-yellow-600 dark:text-yellow-400" />
          <h3 className="text-lg font-bold text-gray-900 dark:text-white">اشتراكات مميزة</h3>
        </div>
        <p className="text-gray-700 dark:text-gray-300 mb-4">
          احصل على إمكانية الوصول لأفضل أدوات الذكاء الاصطناعي من خلال اشتراكاتنا المميزة. 
          نحن نوفر لك الوصول لهذه الأدوات بأسعار مخفضة وخدمة دعم متكاملة.
        </p>
          onClick={() => {
            alert('سيتم توجيهك لصفحة باقات الاشتراك المميزة');
          }}
        <button className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white px-6 py-3 rounded-xl font-semibold hover:shadow-lg transform hover:scale-105 transition-all duration-300">
          استكشف باقات الاشتراك
        </button>
      </div>
    </div>
  );
};

export default AILibrary;