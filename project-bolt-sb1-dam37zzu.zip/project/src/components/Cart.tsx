import React from 'react';
import { Trash2, Plus, Minus, ShoppingBag, CreditCard } from 'lucide-react';

interface CartProps {
  items: any[];
  onRemoveItem: (id: number) => void;
  onBack: () => void;
}

const Cart: React.FC<CartProps> = ({ items, onRemoveItem, onBack }) => {
  const total = items.reduce((sum, item) => {
    const price = parseFloat(item.price.replace(/[^\d.]/g, ''));
    return sum + price;
  }, 0);

  if (items.length === 0) {
    return (
      <div className="text-center py-16">
        {/* Back Button */}
        <div className="flex justify-start mb-6">
          <button
            onClick={onBack}
            className="flex items-center space-x-2 space-x-reverse text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors bg-white dark:bg-gray-800 px-4 py-2 rounded-xl shadow-md hover:shadow-lg"
          >
            <span>← العودة للرئيسية</span>
          </button>
        </div>
        
        <ShoppingBag className="w-24 h-24 text-gray-400 mx-auto mb-6" />
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
          سلة المشتريات فارغة
        </h2>
        <p className="text-gray-600 dark:text-gray-400 mb-8">
          أضف بعض المنتجات إلى سلتك لتبدأ التسوق
        </p>
        <button 
          onClick={onBack}
          className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-3 rounded-xl font-semibold hover:shadow-lg transform hover:scale-105 transition-all duration-300"
        >
          تصفح المنتجات
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header with Back Button */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 space-x-reverse text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors bg-white dark:bg-gray-800 px-4 py-2 rounded-xl shadow-md hover:shadow-lg"
        >
          <span>← العودة للرئيسية</span>
        </button>
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">سلة المشتريات</h1>
        </div>
        <div></div>
      </div>
      
      <div className="text-center">
        <p className="text-gray-600 dark:text-gray-400">
          مراجعة وإدارة مشترياتك
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Cart Items */}
        <div className="lg:col-span-2 space-y-4">
          {items.map((item) => (
            <div key={item.id} className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700">
              <div className="flex items-center space-x-4 space-x-reverse">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-20 h-20 object-cover rounded-lg"
                />
                <div className="flex-1">
                  <h3 className="font-bold text-gray-900 dark:text-white">{item.name}</h3>
                  <p className="text-gray-600 dark:text-gray-400 text-sm">تقييم: {item.rating} ⭐</p>
                </div>
                <div className="text-left">
                  <p className="text-xl font-bold text-blue-600 dark:text-blue-400">{item.price}</p>
                  <div className="flex items-center space-x-2 space-x-reverse mt-2">
                    <button className="p-1 bg-gray-100 dark:bg-gray-700 rounded-md hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors">
                      <Minus className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                    </button>
                    <span className="text-gray-900 dark:text-white font-semibold px-3">1</span>
                    <button className="p-1 bg-gray-100 dark:bg-gray-700 rounded-md hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors">
                      <Plus className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                    </button>
                  </div>
                </div>
                <button
                  onClick={() => onRemoveItem(item.id)}
                  className="p-2 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Order Summary */}
        <div className="lg:col-span-1">
          <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 sticky top-24">
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-6">ملخص الطلب</h3>
            
            <div className="space-y-3 mb-6">
              <div className="flex justify-between text-gray-600 dark:text-gray-400">
                <span>المجموع الفرعي:</span>
                <span>{total.toFixed(2)} ريال</span>
              </div>
              <div className="flex justify-between text-gray-600 dark:text-gray-400">
                <span>رسوم التوصيل:</span>
                <span>15.00 ريال</span>
              </div>
              <div className="flex justify-between text-gray-600 dark:text-gray-400">
                <span>الضريبة:</span>
                <span>{(total * 0.15).toFixed(2)} ريال</span>
              </div>
              <hr className="border-gray-200 dark:border-gray-700" />
              <div className="flex justify-between text-xl font-bold text-gray-900 dark:text-white">
                <span>المجموع الكلي:</span>
                <span>{(total + 15 + (total * 0.15)).toFixed(2)} ريال</span>
              </div>
            </div>

            <button className="w-full bg-gradient-to-r from-green-600 to-emerald-600 text-white py-4 rounded-xl font-semibold hover:shadow-lg transform hover:scale-105 transition-all duration-300 flex items-center justify-center space-x-2 space-x-reverse">
              <CreditCard className="w-5 h-5" />
              <span>إتمام الطلب</span>
            </button>

            <div className="mt-4 text-center">
              <p className="text-xs text-gray-500 dark:text-gray-400">
                دفع آمن ومضمون • شحن سريع
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;