import React from 'react';
import { DivideIcon as LucideIcon } from 'lucide-react';

interface NavigationProps {
  currentSection: string;
  onSectionChange: (section: string) => void;
  sections: Array<{
    id: string;
    title: string;
    icon: LucideIcon;
    description: string;
  }>;
}

const Navigation: React.FC<NavigationProps> = ({ currentSection, onSectionChange, sections }) => {
  return (
    <nav className="hidden lg:block fixed right-0 top-16 h-full w-64 bg-white dark:bg-gray-800 shadow-xl border-l border-gray-200 dark:border-gray-700 overflow-y-auto">
      <div className="p-4">
        <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-4 text-center">
          قائمة الخدمات
        </h2>
        <div className="space-y-2">
          {sections.map((section) => (
            <button
              key={section.id}
              onClick={() => onSectionChange(section.id)}
              className={`w-full flex items-center space-x-3 space-x-reverse p-3 rounded-xl transition-all duration-300 group ${
                currentSection === section.id
                  ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg'
                  : 'hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300'
              }`}
            >
              <div className={`p-2 rounded-lg transition-colors duration-300 ${
                currentSection === section.id
                  ? 'bg-white/20'
                  : 'bg-gray-100 dark:bg-gray-600 group-hover:bg-gray-200 dark:group-hover:bg-gray-500'
              }`}>
                <section.icon className={`w-5 h-5 ${
                  currentSection === section.id ? 'text-white' : 'text-gray-600 dark:text-gray-300'
                }`} />
              </div>
              <div className="text-right flex-1">
                <h3 className="font-semibold">{section.title}</h3>
                <p className={`text-xs leading-tight ${
                  currentSection === section.id
                    ? 'text-white/80'
                    : 'text-gray-500 dark:text-gray-400'
                }`}>
                  {section.description}
                </p>
              </div>
            </button>
          ))}
        </div>
      </div>
    </nav>
  );
};

export default Navigation;