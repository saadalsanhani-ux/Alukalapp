import React, { useState, useEffect } from 'react';
import { Calendar, Clock } from 'lucide-react';

const DateTimeDisplay: React.FC = () => {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Hijri date calculation (simplified)
  const getHijriDate = (gregorianDate: Date) => {
    const hijriEpoch = new Date('622-07-16'); // Approximate start of Hijri calendar
    const daysDiff = Math.floor((gregorianDate.getTime() - hijriEpoch.getTime()) / (1000 * 60 * 60 * 24));
    const hijriYear = Math.floor(daysDiff / 354.37) + 1; // Approximate Hijri year length
    const remainingDays = daysDiff % 354;
    const hijriMonth = Math.floor(remainingDays / 29.5) + 1;
    const hijriDay = Math.floor(remainingDays % 29.5) + 1;
    
    const hijriMonths = [
      'محرم', 'صفر', 'ربيع الأول', 'ربيع الثاني', 'جمادى الأولى', 'جمادى الثانية',
      'رجب', 'شعبان', 'رمضان', 'شوال', 'ذو القعدة', 'ذو الحجة'
    ];
    
    return `${hijriDay} ${hijriMonths[hijriMonth - 1]} ${hijriYear}هـ`;
  };

  const formatGregorianDate = (date: Date) => {
    const months = [
      'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
      'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
    ];
    return `${date.getDate()} ${months[date.getMonth()]} ${date.getFullYear()}م`;
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('ar-EG', { 
      hour: '2-digit', 
      minute: '2-digit',
      second: '2-digit',
      hour12: true 
    });
  };

  return (
    <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-3 border border-gray-200 dark:border-gray-600">
      <div className="flex items-center space-x-3 space-x-reverse">
        <div className="flex items-center space-x-2 space-x-reverse">
          <Clock className="w-4 h-4 text-blue-600 dark:text-blue-400" />
          <span className="text-sm font-bold text-gray-900 dark:text-white">
            {formatTime(currentTime)}
          </span>
        </div>
        <div className="hidden sm:block h-4 w-px bg-gray-300 dark:bg-gray-600"></div>
        <div className="hidden sm:flex items-center space-x-2 space-x-reverse">
          <Calendar className="w-4 h-4 text-purple-600 dark:text-purple-400" />
          <div className="text-xs">
            <div className="text-gray-900 dark:text-white font-medium">
              {formatGregorianDate(currentTime)}
            </div>
            <div className="text-gray-600 dark:text-gray-400">
              {getHijriDate(currentTime)}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DateTimeDisplay;